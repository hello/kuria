from __future__ import print_function
import sys, os
from distutils.core import setup

# This will import __version__ from __version__.py
execfile('pyradarlib4/__version__.py')


name='pyradarlib4'

setup(name=name,
      version=__version__,
      description='Python library for connecting to X4',
      author='Novelda AS',
      author_email='support@xethru.com',
      packages=['pyradarlib4', 'pyradarlib4.regmap', 'pyradarlib4.apps'],
      package_data = {'pyradarlib4': [r'doc/X4 - pyradarlib4 Introduction.ipynb']},
      )

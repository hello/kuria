import logging

class RadarPhyFactory(object):
    @staticmethod
    def getconnection(connectionstring):
        if connectionstring == 'auto':
            port = find_s70_usb()
        elif connectionstring == 'loopback':
            return LoopbackPhy()
        else:
            port = connectionstring

        serialport = RadarPhyFactory._initialize_serial(port)
        return serialport



    @staticmethod
    def _initialize_serial(portinfo):
        import serial
        port = serial.Serial()
        port.port = portinfo
        port.baudrate = 4000000 #921600
        port.bytesize = serial.EIGHTBITS
        port.stopbits = serial.STOPBITS_ONE
        port.parity = serial.PARITY_NONE
        port.timeout = 3
        port.xonxoff = False
        port.WriteTimeout = 4
        return port


class LoopbackPhy(object):
    def __init__(self):
        self.buffer = bytearray
        self.logger = logging.getLogger('loopbackphy')
        self.out_data = bytearray()
        self.in_data = bytearray()

    def open(self):
        self.logger.info("open")

    def isOpen(self):
        return True

    def write(self,data):
        self.out_data.extend(data)

    def inWaiting(self):
        return len(self.in_data)

    def read(self,cnt):
        ret = bytearray()
        try:
            for i in range(0,cnt):
                ret.extend(self.in_data.pop(0))
        except IndexError:
            pass
        return ret

class RadarPhyError(Exception):
    """! Represent an exception that occurred in the layer
    """

    def __init__(self, value):
        self.value = value

    def __str__(self):
        return repr(self.value)




def find_s70_usb(prefer_port=None):
    """! This function searches all available comports for potential s70 USB connections.
    Optionally, you can specify a preferred port using the prefer_port option.

    The returned port is not tested to actual be a s70 device.

    Raises IOError if no suitable port is found.

    Returns a PortInfo object with information about the port
    @param prefer_port: The perferred port
    """
    from serial.tools import list_ports
    terms = ['Communication Device Class ASF example', 'USB VID:PID=03EB:2404']

    ports = list_ports.comports()

    for port in ports:
        if prefer_port:
            if port[0] != prefer_port:
                continue
        elif terms[1] not in port[2] and terms[0] not in port[1]:
            continue

        name = port[0]
        description = port[1]
        hwid = port[2]
        return name


    raise RadarPhyError(
        """Serial port search failed. %s does not seem to exist in this system.
        \nPlease check that the usb cable is connected to system.""" % (
            ' OR '.join([s for s in terms])))
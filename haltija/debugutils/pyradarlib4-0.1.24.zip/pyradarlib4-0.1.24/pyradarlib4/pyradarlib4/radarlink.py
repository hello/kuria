import Queue
import logging

from radardefinitions import *
import copy
from time import time, sleep
import struct
import threading


FAST_DATA_DATA_OFFSET = 1 + 1 + 4
FAST_DATA_LENGTH_OFFSET = 1 + 1
content_base = 6

class RadarLinkError(Exception):
    """! Represent an exception that occurred in the Link layer
    """

    def __init__(self, value):
        self.value = value

    def __str__(self):
        return repr(self.value)


class RadarMessage(object):
    """! Represent a basic communication message
    """

    def __init__(self, identifyer=0, crc=False):
        """! Initialize a new RadarMessage object
        
        @param identifyer A unique integer id number for the message
        @param crc True if the message has passed crc check
        """
        self.id = identifyer
        self.msg = bytearray()
        self.crc = crc

    def __str__(self):
        return "Message id %d: %s" % (self.id, self.msg)

    def get_status(self):
        return self.msg[7]
    def content_as_hex(self):
        i=0
        rsp = ""
        for x in self.msg:
            rsp += "[%d]0x%x\n" % (i ,x )
            i+=1
        return rsp




class Frame():
    """
    Class for keeping frame number and data.

    """
    def __init__(self,number, data, status,timestamp,i32_timer_clock):
        """
        @param number: Frame number
        @param data: Frame data
        @param status:  0x01 indicate that the delta between this frame and the previous frame is more than 10% off
                        from the desired frame rate.
                        0x02: indicate that the accumulated error is more than 10 frames long. updated every 10 frames.
                        0x80: indicate that the frame sampling has timed out, the sampling timeout is either to
                        aggressive or the X4 is unresponsive.
        @param timestamp: 64 bit timestamp running at i32_timer_clock Hz
        @param i32_timer_clock: 32 bit value for timer counter clock
        """
        self.number = number
        self.data = data
        self.status = status
        self.timestamp = timestamp
        self.timerclock =i32_timer_clock

def process_raw_streamed_frame(frame, iq=False,bytes_per_sampler=3,link=None):
    """

    @param frame: Raw Link message containing frame data
    @param iq: handle iq frame or normal frame
    @return:
    """
    i24frame = unpack_frame(frame, iq=iq,bytes_per_sampler=bytes_per_sampler)
    i32_frameCounter = (frame.msg[content_base] | frame.msg[content_base+1] << 8 | frame.msg[content_base+2] << 16| frame.msg[content_base+3]<< 24)
    timestamp_base = content_base+4
    i64_timestamp  = (frame.msg[timestamp_base] | frame.msg[timestamp_base+1] << 8 | frame.msg[timestamp_base+2] << 16| frame.msg[timestamp_base+3]<< 24| frame.msg[timestamp_base+4]<< 32 | frame.msg[timestamp_base+5]<< 40| frame.msg[timestamp_base+6]<< 48| frame.msg[timestamp_base+7]<< 54)

    timerclock_base = timestamp_base+8
    i32_timer_clock  = (frame.msg[timerclock_base] | frame.msg[timerclock_base+1] << 8 | frame.msg[timerclock_base+2] << 16| frame.msg[timerclock_base+3]<< 24)
    status_offset = timerclock_base+4


    status = frame.msg[status_offset]
    if status & 0x01 == 0x01:
        if link != None:
            if link.stream_bad_flag == False:
                link.logger.warn("Stream has a frame with 10% decreased framerate, check status flags and timestamps for correct frame sampling")
                link.stream_bad_flag = True
    return Frame(i32_frameCounter,i24frame,status,i64_timestamp,i32_timer_clock)

def unpack_frame(frame, frame_offset = 17, iq=False,bytes_per_sampler=3):
    """
    Unpacks raw data frames.
    @param frame: raw frame data
    @param frame_offset: offsett to find frame
    @param iq: unpack iq frame
    @return:
    """
    content_frame_start = content_base + frame_offset
    radar_buffer = frame.msg[content_frame_start:]


    if iq:
        return unpack_iqframe(radar_buffer)
    else:
        return unpack_frame2(radar_buffer,bytes_per_sampler)

def unpack_sampler(data,bytes_per_frame):
    sampler = 0
    for i in range(0,bytes_per_frame):
        sampler += data[i] << 8*i
    return sampler

def unpack_frame2(radar_buffer,bytes_per_frame=3):
    """
    NOTE: Function assumes that rx_counter_num_bytes = 3
    @param radar_buffer: buffer with frame data
    @return: packed i24 frame
    """

    i24frame = []
    #bytes_per_frame = 3
    #print bytes_per_frame
    for i in range(len(radar_buffer) / bytes_per_frame):
        data = radar_buffer[bytes_per_frame * i:bytes_per_frame * (i + 1)]
        i24 = unpack_sampler(data,bytes_per_frame)#(data[0] | data[1] << 8 | data[2] << 16)
        i24frame.append(i24)
    return i24frame

def unpack_iqframe(radar_data):
    """ Unpack an IQ downconverted frame
    Returns the unpacked frame as complex values
    
    Todo: The function assumes that rx_counter_num_bytes = 6   
    
    """
      
    def sign_extend(value):
        if value & (1<<47):
            value = -((~value & ((1<<48) - 1)) + 1)
        return value
      
    max_data = len(radar_data)
      
    cdata = []
    for i in range(max_data / 12):
        data = radar_data[12 * i:12 * (i + 1)]
        idata = data[0] | (data[1] << 8) | (data[2] << 16) | (data[3] << 24) | (data[4]  << 32) | (data[5]  << 40)
        idata = sign_extend(idata) 
        qdata = data[6] |  data[7] << 8  |  data[8] << 16  |  data[9] << 24  |  data[10] << 32  |  data[11] << 40
        qdata = sign_extend(qdata)
        cdata.append(complex(qdata, idata) )
     
    return cdata

def crc8_int(data):
    crc = 0x00
    for c in data:
        crc ^= c
    return crc


def crc8_str(data):
    crc = 0x00
    for c in data:
        crc ^= c
    return crc


def escape_byte(b):
    if b in SerialFlagByte.values:
        return [SerialFlagByte.XTS_FLAG_ESC, b]
    return [b]


def escape_data(data):
    a = []
    for c in data:
        a.extend(escape_byte(c))
    return a



class FAST_DATA_STAGE(object):
    IDLE = 0
    GET_LENGTH = 1
    GET_DATA = 2
    GET_FRAME_COUNTER = 4
    DONE = 3

class RadarLink(object):
    """
    The RadarLink class represent the data link layer of radar  .
    """

    def __init__(self, phy,):
        """
        Construct a new RadarLink object. The port needs to be opened with the open method.
        
        @param phy: Port to communicate to radar.
        @param max_msgqueue_size: Set the maximum size for the incoming message
                                  queue. Default is 1000
        """
        self.logger = logging.getLogger('RadarLink')
        if not phy:
            raise RadarLinkError("No phy")
        print phy
        self.prev_byte_was_start = False
        self.fast_stage = FAST_DATA_STAGE.IDLE
        self.msgqueue = Queue.Queue(1000)
        self.phy = phy
        self.msg = None
        self._thread = threading.Thread(target=self._run)
        self.escape = False
        self.crc_fails = 0
        self.rxmsgs = 0
        self.txmsgs = 0
        self._run_reader = False
        self._use_read_thread = True
        self.stream_bad_flag = False
        self.fps_deviance_allowed = 0
        self.crc = SerialFlagByte.XTS_FLAG_START
        self._frame_buffer = None
        self._iq = False
        self.txbuffer = bytearray()
        self.last_txbuffer = []
        self.last_write = []
        #todo remove, performace map
        self.map = dict()
        self.time_records = []
        self.total_bytes_rx = 0
        self.total_bytes_tx = 0
        self.fast_type = None
        self.fast_cnt = 0

    def print_state(self):
        print "self.prev_byte_was_start ",self.prev_byte_was_start
        print "self.fast_stage " , self.fast_stage
        print "msg ", self.msg
        print "escape " , self.escape
        print "self.crc_fails ", self.crc_fails
        print "self.rxmsgs ", self.rxmsgs
        print "self.txmsgs ", self.txmsgs
        print "self._run_reader ", self._run_reader
        print "self._use_read_thread ", self._use_read_thread
        print "self.crc ", self.crc
        print "self.txbuffer" , self.txbuffer
        print "self.last_txbuffer", self.last_txbuffer
        print "self.txbuffer", self.txbuffer
        print "self.last_write", self.last_write
        print "self.map", self.map
        print "self.total_bytes_rx", self.total_bytes_rx
        print "self.total_bytes_tx", self.total_bytes_tx

    def isopen(self):
        """! Return true if the serial port is open
        """
        return self.phy.isopen()


    def _run(self):
        while self._run_reader:
            self.update()

    def open(self):
        """! Open the serial port connection.
        """
        ret = self.phy.open()
        if self._use_read_thread:
            self._run_reader = True
            self._thread = threading.Thread(target=self._run)
            self._thread.daemon = True
            self._thread.start()
        return ret

    def close(self):
        """! Close the serial port connection
        """
        self._run_reader = False
        return self.phy.close()

    def write_byte(self, c):
        """!
        Append a byte to internal buffer
        @param c The char or array of chars to append

        """

        try:
            ci = iter(c)
        except TypeError:
            ci = [c]

        for cx in ci:
            if cx < 256:
                self.crc ^= cx
                self.txbuffer.append(cx)
            else:
                raise RadarLinkError("Unable to convert %s to 8-bit char" % c)

    def write_uint32(self, i):
        """!
        Write unsigned 32 bit int to internal buffer
        """
        buffer = bytearray(4)
        struct.pack_into('I',buffer,0,i)
        self.write_byte(buffer)

    def write_uint64(self, i):
        """!
        Write unsigned 64 bit int to internal buffer
        """
        buffer = bytearray(8)
        struct.pack_into('Q', buffer, 0, i)
        self.write_byte(buffer)


    def flush(self):
        """!
        Send data currently in txbuffer
        
        Start, stop, CRC and escape bytes are appended as needed.
        
        Note that if the object was instantiated with no_connect=False, the serial
        port will not be open. In this case, the function will emulate the writing 
        and return the number of bytes it would have transferred in the normal case.
        
        @return The number of bytes transferred

        """
        xdata = bytearray([SerialFlagByte.XTS_FLAG_START])
        xdata.extend(escape_data(self.txbuffer))
        xdata.extend(escape_data([self.crc]))
        xdata.append(SerialFlagByte.XTS_FLAG_END)

        self.last_txbuffer = copy.copy(self.txbuffer)
        self.last_write = copy.copy(xdata)

        self.txbuffer = []
        self.crc = SerialFlagByte.XTS_FLAG_START

        if self.phy.isOpen():
            self.logger.debug("Writing message %d" % self.txmsgs)
            self.txmsgs += 1
            self.total_bytes_tx += long(len(xdata))
            return self.phy.write(xdata)
        else:
            return long(len(xdata))

    def clear(self):
        """! Clear msg queue
        """
        with self.msgqueue.mutex:
            self.phy.read(self.phy.inWaiting() or 1)
            self.msgqueue.queue.clear()

    def update(self):
        """! Alias for read_all_and_parse()
        """
        self.read_all_and_parse()


    def set_frame_buffer(self,buffer, iq=False,bytes_per_sampler=3):
        self._frame_buffer = buffer
        # Note: This introduces a statefulness in this object that might
        #       cause problems down the line, for instance if the user changes
        #       the rx_downconversion register without updating this
        #       local _iq variable
        self.stream_bad_flag = False
        self._iq = iq
        self._bytes_per_sampler = bytes_per_sampler

    def read_all_and_parse(self):
        """! Check the serial port for incoming data and parse any new data.
        New messages are pushed into the msgqueue FIFO buffer
        
        @return None
        """
        iw = self.phy.inWaiting()
        #if not iw:
        #    return

        try:
            v = self.map[iw]
        except KeyError:
            self.map[iw] = 0

        self.map[iw] += 1
        buf = self.phy.read(iw or 1)

        self.parse(buf)





    def parse(self, idata):
        """! Parse the supplied data
        
        @param data: data to be parsed
        @return None
        """
        rx_data_size = len(idata)
        self.total_bytes_rx += rx_data_size
        data = bytearray(idata)
        start = time()
        i = -1
        while i < rx_data_size-1:
            i += 1
            char = data[i]



            if not self.escape:                                                                      #
                if self.prev_byte_was_start and ((char == SerialProtocolResponse.XTS_SPR_DATA_FAST) or (char == SerialProtocolResponse.XTS_SPR_APPDATA_FAST)):
                    self.fast_stage = FAST_DATA_STAGE.GET_LENGTH
                    self.prev_byte_was_start = False
                    self.fast_type = char




                elif self.fast_stage == FAST_DATA_STAGE.GET_LENGTH:
                    self.msg.msg.append(char)
                    if len(self.msg.msg) == 1+1+4: #start + data_type + length32



                        self.fast_stage = FAST_DATA_STAGE.GET_DATA

                        import radarutil
                        self.length = radarutil.btoi(self.msg.msg[FAST_DATA_LENGTH_OFFSET:FAST_DATA_DATA_OFFSET])
                        self.fast_data_rcv = 0

                    continue
                elif self.fast_stage == FAST_DATA_STAGE.GET_DATA:

                    length = self.length
                    # i is current data
                    # size will be last index +1
                    rx_data_left = (rx_data_size) - (i)

                    i_start = i


                    data_to_add = length - self.fast_data_rcv

                    recived_more_than_the_data_we_need = rx_data_left >= data_to_add

                    if recived_more_than_the_data_we_need:
                        the_data_we_are_adding = data[i:i + data_to_add]
                        if i + data_to_add < len(data):
                            lb = data[i + data_to_add]
                            if lb != SerialFlagByte.XTS_FLAG_END:
                                self.logger.error("Expected SerialFlagByte.XTS_FLAG_END got %s",hex(lb))
                        self.msg.msg.extend(the_data_we_are_adding)

                        i = i + data_to_add

                        if self.fast_type == SerialProtocolResponse.XTS_SPR_APPDATA_FAST:
                            if self._frame_buffer:

                                frame = process_raw_streamed_frame(self.msg, self._iq,self._bytes_per_sampler,self)
                                self._frame_buffer.put_nowait(frame)

                        else:
                            self.msgqueue.put_nowait(self.msg)
                        self.msg = None
                        self.fast_stage = FAST_DATA_STAGE.DONE
                        continue

                    recived_less_than_the_data_we_need = rx_data_left < data_to_add
                    if recived_less_than_the_data_we_need:
                        last_rx_buffer_index = rx_data_size
                        the_data_we_are_adding = data[i:last_rx_buffer_index]
                        self.fast_data_rcv += len(the_data_we_are_adding)
                        self.msg.msg.extend(the_data_we_are_adding)
                        break
                    raise Exception("ERROR")

                    continue
                elif char == SerialFlagByte.XTS_FLAG_ESC:
                    self.escape = True
                    continue
                elif char == SerialFlagByte.XTS_FLAG_START:
                    self.logger.debug("Message start")
                    self.msg = RadarMessage(self.rxmsgs)
                    self.rxmsgs += 1
                    self.prev_byte_was_start = True
                    #self.msg.msg += char
                    #print "self.rxmsgs", self.rxmsgs
                    self.msg.msg.append(char)
                    continue
                elif char == SerialFlagByte.XTS_FLAG_END:

                    if self.msg:
                        if self.fast_stage != FAST_DATA_STAGE.DONE:
                            crc_calc = crc8_int(self.msg.msg[:-1])
                            crc_msg = self.msg.msg[-1]
                            if crc_calc != crc_msg:
                                self.logger.debug(
                                    "Message id %d: CRC check failed. Calculated %d expected %d. Dropping message" % (
                                        self.msg.id, crc_calc, crc_msg))
                                self.crc_fails += 1
                                self.msg = None
                                continue
                            else:
                                self.logger.debug("Message id %d: CRC check ok" % self.msg.id)
                                self.msg.crc = True
                        else:
                            self.fast_stage = FAST_DATA_STAGE.IDLE

                        self.msgqueue.put_nowait(self.msg)
                        self.msg = None

            if self.msg:
                self.msg.msg.append(char)
            self.escape = False
            self.prev_byte_was_start = False
        self.time_records.append(time() - start )

    def __exit__(self, *args):
        """ 
        For PEP 343:
        Called when object is destroyed when exiting with statement
        Makes sure the class cleans up after it self by stopping the 
        firmware and closing the connection. 
        """
        self.close()

    def getmessage(self, timeout=3):
        """!Gets a message or wait for one until timeout
        
        @param timeout: timeout in seconds
        @return: a message or false
        """
        now = time()

        while 1:
            # Check for timeout
            if time() - now > timeout:
                return False

            try:
                if not self._use_read_thread:
                    self.update()
                    msg = self.msgqueue.get_nowait()
                else:
                    msg = self.msgqueue.get(block=True,timeout=timeout)
            except Queue.Empty:
                sleep(0)
                continue
            return msg

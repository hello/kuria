""" pyRadarlib4 version bookkeeping

This file is modified by the handle_version.py script
as part of the release job. In the repository it shall
always be set to 0.0.0.

"""
__version__ = "0.1.24"

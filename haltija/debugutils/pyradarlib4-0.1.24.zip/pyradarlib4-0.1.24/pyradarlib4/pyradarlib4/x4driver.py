#!/usr/bin/env python
""" X4Driver, a higher level library to the X4 universe

This module uses pyradarlib4 to give simpler access to the X4 chip
"""

from pyradarlib4 import PyRadarlib4
import logging
from time import sleep, time
from numpy import array, bitwise_and
import Queue
from collections import deque

class X4DriverError(Exception):
    """! Represent an exception that occurred in the X4Driver
    """

    def __init__(self, value):
        self.value = value

    def __str__(self):
        return repr(self.value)
        
class DiscardingFrameQueue(Queue.Queue):
           
    def _init(self,maxsize):
        self.queue = deque(maxlen=maxsize)
          
    def put(self, frame, *args, **kwargs):
        """Override put function
        """
        self.mutex.acquire()
        self._put(frame.data)
        self.mutex.release()

    def _put(self, item):
        self.queue.append(item)
        
        
class X4Driver(PyRadarlib4):
    def __init__(self, connect_string = 'auto', chip = 'nva5ic001', loglevel=logging.INFO):
        """! Initialize a new X4Driver object
        
        """
        super(X4Driver, self).__init__(connect_string = connect_string, chip = chip)
        
        self.log = logging.getLogger("X4Driver")
        self.log.setLevel(loglevel)
        
        self.x4setup()
        self.default_setup()
        
        
    
    def x4setup(self):
        """! Setup basic functionality of X4 
        """
        self.x4_reset()
        # Program embedded 8051 firmware to enable communication with PIF registers from SPI
        self.logger.debug("Programmig and validating 8051 firmware")
        self.programEmbedded8051Firmware()
        self.logger.debug("Programming and validation of 8051 firmware done")
        self.enable_ldos()
        self.setup_xosc()

    def set_log_level(self, loglevel=logging.INFO):
        """! Convenience function for updating log-level
        
        >>> import logging
        >>> import pyradarlib4
        >>> radar = pyradarlib4.X4Driver()
            ...
        >>> # To set default log level
        >>> radar.set_log_level(logging.INFO)
        >>> # To enable debug messages
        >>> radar.set_log_level(logging.DEBUG)
        >>> # To only let warning messages or worse through
        >>> radar.set_log_level(logging.WARNING)
        >>> radar.close()
        """
        self.log.setLevel(loglevel)
        
    def enable_ldos(self):
        """! Enable on-chip LDOs
        """
        # Enable LDO
        if self.enable_dvdd_tx():
            self.log.info("DVDD TX OK")
        else:
            raise X4DriverError("DVDD TX enabling failed")
        
        
        if self.enable_dvdd_rx():
            self.log.info("DVDD RX OK")
        else:
            raise X4DriverError("DVDD RX enabling failed")
            
        if self.enable_avdd_tx():
            self.log.info("AVDD TX OK")
        else:
            raise X4DriverError("AVDD TX enabling failed")

        if self.enable_avdd_rx():
            self.log.info("AVDD RX OK")
        else:
            raise X4DriverError("AVDD RX enabling failed")    
        
    def default_setup(self):
        """! Setup X4 with default settings
        """
        
        #self.set_fw_frame_size(1536*3)
        
        # Set receiver trimming values
        self.reg.dac_trim_a = 7
        self.reg.dac_trim_b = 7
        self.reg.preamp_trim = 15
        # Enable Common PLL 243MHz
        self.reg.common_pll_powerdown=0
        sleep(1e-3)
        self.logger.info("Common PLL lock: %s" % (self.reg.common_pll_lock==1))
        # Enable TX PLL, default is 243*5 MHz (ETSI) 
        self.reg.tx_pll_powerdown=0
        sleep(1e-3)
        self.logger.info("TX PLL lock: %s" % (self.reg.tx_pll_lock == 1))
        # Enable RX PLL 1.944 GHz (243*8)
        self.reg.rx_pll_powerdown=0
        sleep(1e-3)
        self.logger.info("RX PLL lock: %s" % (self.reg.rx_pll_lock == 1))
        self.logger.debug("System Fs is then: %s GS/s" % (243*8*12/1e3))
        
        # Enable receiver backend clocks
        # 
        self.reg.pllauxclk_sel = 1
        self.reg.trx_backend_clk_prescale = 1
        self.reg.trx_backend_clk_div = 0
        
        # Enable sampler
        self.reg.sampler_preset_en = 0
        self.reg.powerdown_sampler = 0
        #Configuration of transmitter Transmitter can be configured with different TX power and output frequency. By default the transmitter is disabled
        # Set TX power
        # 0 - OFF
        # 1 - Low
        # 2 - Medium
        # 3 - High
        self.reg.tx_power = 2
         
        # Set TX center frequency
        # 3 - 7.290 GHz (EU / US)
        # 4 - 8.748 GHz (KCC)
        self.set_tx_region('eu')
        
        #Configuration of sweep parameters By default the chip starts with full dac range and some averaging. To modify, the following registers are most important
        
        
        # Set up full DAC range
        # Dac registers are 11 bit
        self._dacmin = 0
        self._dacmax = 2047
        self._pps = 10
        self._it =8
        self.set_dacmax(self._dacmax)
        self.set_dacmin(self._dacmin)
        self.set_pps(self._pps)
        
        # Iterations should be a power of 2
        # If iterations = 2, trx_auto_bidir_enable should be 0
        # Power of two sweeps are in same direction is needed for bi-phase sampling
        self.reg.trx_iterations          = self._it
        
        # Set up PRF
        # PRF is 243 MHz / trx_clocks_per_pulse
        # Max PRF is 243 / 4 = 60.75 MHz
        # 243/16. = 15.1875 MHz
        prfhz = self.set_prf(16)
        self.log.debug("PRF set to %g MHz"%(prfhz/1e6))
         
        # Set up frame length
        # rx_mframes_coarse set the number of samplers in steps of 96
        # so max number of samplers is 96 x 16 = 1536
        # rx_mframes_coarse must be <= trx_clocks_per_pulse
        self.reg.rx_mframes_coarse = 16
         
        # Set frame offset in steps of 1/243 = ~4.12 ns
        # Max value is 255
        self.reg.rx_wait = 0
         
        # If desirable, set transmitter wait (to see behvior at start of pulse or just before for instance)
        self.reg.tx_wait = 1

        self.set_frame_length(self.reg.rx_mframes_coarse)
        

    def check_configuration(self):
        """! Check sanity of current configuration
        
        If a problem is found, the function will generate log messages depending on 
        the severity of the configuration problem.
        
        Returns True if the configuration is OK.
        """
        conclusion = True
        
        # Check iterations
        if (self.reg.trx_iterations % ((2**self.reg.noiseless_ghost_order) * (2**self.reg.trx_auto_bidir_enable))):
            self.logger.warning("trx_iterations should be divisible by (2^noiseless_ghost_order) * (2^trx_auto_bidir_enable)")
            conclusion = False            
        else:
            self.logger.debug("trx_iterations setting OK")
                
        # The current version of FW/SW don't support other configurations of bytes-per-counter
        if (self.reg.rx_counter_num_bytes != 3):
            conclusion = False
            self.logger.warning("This version of pyradarlib doesn't support other values for rx_counter_num_bytes than 3.")
            
        # The same applies to the counter bit-shift
        if (self.reg.rx_counter_lsb != 0):
            conclusion = False
            self.logger.warning("This version of pyradarlib doesn't support other values for rx_counter_lsb than 0.")
                
        # Check frame length vs PRF
        if self.reg.trx_clocks_per_pulse < self.reg.rx_mframes_coarse:
            self.logger.error("trx_clocks_per_pulse must be >= rx_mframes_coarse")
            conclusion = False
        else:
            self.logger.debug("trx_clocks_per_pulse and rx_mframes_coarse settings OK")

        # Check that we don't overflow counters
        ds = 2**self.reg.trx_dac_step_clog2
        dr = ((((self.reg.trx_dac_max_h<<3)+self.reg.trx_dac_max_l) - ((self.reg.trx_dac_min_h<<3)+self.reg.trx_dac_min_l)) / ds) + 1
        pps = self.reg.trx_pulses_per_step_lsb + (self.reg.trx_pulses_per_step_msb << 8)
        
        if (pps * dr * self.reg.trx_iterations) > ((2**24)-1):
            self.logger.error("Hardware countes are 24 bit, maximum integrated value should be less than 2^24 to avoid counter overflow")
            conclusion = False
        else:
            self.logger.debug("Maximum integrated counter value OK")

        # Check of rare drop of bits issue could occur
        trx_backend_clk_totaldiv = ([2,4,6,8][self.reg.pllauxclk_sel]) * 2**(self.reg.trx_backend_clk_prescale-1) * (self.reg.trx_backend_clk_div+1)
        if (trx_backend_clk_totaldiv + 2**self.reg.trx_dac_settle_clog2) >= self.reg.trx_clocks_per_pulse:
            self.logger.warning("Safe conditions for avoiding rare drop of bits issue in receiver backend may not be met.")
            conclusion = False

        # Check that backend clock is fast enough to have sufficient time to read out ripple counters
        if (trx_backend_clk_totaldiv > ((511 * self.reg.trx_clocks_per_pulse)/(self.reg.rx_mframes*3 + 3))):
            self.logger.warning("Total trx_backend_clk division must be must be less than ((511 * trx_clocks_per_pulse)/(rx_mframes*3 + 3))")
            conclusion = False
            
        return conclusion
    

    def _get_lsb_msb(self, val):
        """! Splits a 16 bit value to 8 lower bits (lsb) and 8 upper bits (msb)
        
        Variables > 8 bits are split into to chip registers.
        """
        if (val >= 2**16):
            raise X4DriverError("val must be lower than 2**16")
        return bitwise_and(val, 2**8-1), val >> 8
    
    def _get_l_h(self, val):
        """! Splits an integer to the 3 lover bits (l) and 8 upper bits (h)
        
        This convention is used for the dacmin/dacmax variable,
        """
        if (val >= 2**11):
            raise X4DriverError("val must be lower than 2**13")
        return bitwise_and(val, 2**3-1), val >> 3
     
     
    def set_prf(self, val):
        """! Set the Pulse Repetition Frequency (PRF)
        
        The PRF is set to 243 MHz / prf_val.
        The allowed range is 4-255
        
        Returns the PRF in MHz
        """
        if (val > 255):
            raise X4DriverError("PRF val must be lower than 255")
        elif (val < 4):
            raise X4DriverError("PRF val must be 4 or higher")
        self.reg.trx_clocks_per_pulse = val
        
        return self.get_prf()
    
    def get_prf(self):
        """!Get the configured PRF
        
        Returns:
            Frequency in hz
        """
        return 243e6 / self.reg.trx_clocks_per_pulse
    
    def set_sample_delay(self, val):
        """!Set the sample delay (a.k.a frame offset)
        
        The sample delay is set in increments of 1.0/243.0e6 seconds
        
        Returns the sample delay in seconds
        """    
        self.reg.rx_wait = val
        return self.get_sample_delay()
    
    def get_sample_delay(self):
        """!Get the sample delay (a.k.a frame offset)
        
        Returns:
            The sample delay in seconds
        """    
        
        return self.reg.rx_wait/243.0e6
     
    def set_frame_length(self, val):
        """! Set the length (duration) of the frame

        The frame length is set in increments of 96 range bins
        The allowed range for frame length is 4-255

        Returns the number of range bins in the frame
        """
        if (val > 255):
            raise X4DriverError("frame length val must be lower than 255")
        elif (val < 4):
            raise X4DriverError("frame length val must be 4 or higher")
        # Coarse setting controls how long the samplers are active per 1-bit frame
        # Sets frame length in increments of 96 bins (which is the same as one 243MHz period)
        self.reg.rx_mframes_coarse = val
        # Fine settings controls how much of the sampled frame to actually store in SRAM
        # Sets the frame length in increments of microframes (=12 range bins)
        self.reg.rx_mframes = val*96/12
        # Tell the FW to only read the specified number of bytes
        nrangebins = val*96
        self.radar.set_fw_frame_size(nrangebins*self.reg.rx_counter_num_bytes)
        return nrangebins
        
    def set_iterations(self, val):
        """! Sets the trx_iterations chip register
        
        Updates normalization parameters
        
        """
        self.reg.trx_iterations = val
        self._it = val
        
        self._update_normalization()

    def get_iterations(self):
        """! Gets the trx_iterations chip register
        """
        self._it = self.reg.trx_iterations
        
        return self._it
        
    def set_pps(self, val):
        """! Sets the pulses_per_step registers
        
        Updates normalization parameters
        
        """
        self._pps = val
        lsb, msb = self._get_lsb_msb(val)
        self.reg.trx_pulses_per_step_lsb = lsb
        self.reg.trx_pulses_per_step_msb = msb
        
        self._update_normalization()

    def get_pps(self):
        self._pps = self.reg.trx_pulses_per_step_lsb + (self.reg.trx_pulses_per_step_msb << 8)
        return self._pps
        
    def set_dacmin(self, val):
        """! Sets the dac_min registers.
        """
        self._dacmin=val
        var = "dacmin"
        max = 2**11-1 
        if val >= max:
            raise X4DriverError("Maximum variable value of %s is %d"%(var, max))
        l, h = self._get_l_h(val)
        self.reg.trx_dac_min_l = l
        self.reg.trx_dac_min_h = h
        
        self._update_normalization()
        
    def set_dacmax(self, val):
        """! Sets the dac_max registers.
        """
        self._dacmax=val
        var = "dacmax"
        max = 2**11-1 
        if val > max:
            raise X4DriverError("Maximum variable value of %s is %d"%(var, max))
        
        l, h = self._get_l_h(val)
        self.reg.trx_dac_max_l = l
        self.reg.trx_dac_max_h = h
        
        self._update_normalization()
        
        
    def _update_normalization(self):
        self._noffset = (2047-self._dacmax + self._dacmin)/2.
        self._nfactor = 1.0*self._it*self._pps 
    
    def normalize_frame(self, frame):
        """! Normalizes chip counter values to the actual DAC value (0-2047)
        """
        return array(frame)/self._nfactor+self._noffset
    
    def get_frame_normalized(self):
        """! Samples and normalizes a radar frame.
        
        Convenience function to sample 1 frame. Use streaming to sample several
        frames.
        
        Returns:
            Normalized frame as a numpy array
        """
        
        if not self.reg.rx_downconversion_enable:
            sample = self.sample_frame
        else:
            sample = self.sample_iq_frame
            
        return self.normalize_frame(sample())

    
    def get_fs(self):
        """!Get the radar system sampling rate.
        
        Returns:
            Sampling rate in Hz
        """
        if self.reg.rx_downconversion_enable:
            f=8.0
        else:
            f=1.0
        return  243*8*12/1e3*1e9/f
    
    def get_sweeptime(self):
        "Calculate the actual sweep time with the current radar settings"
        raise NotImplementedError
        
        
    def get_frames_normalized(self, n, fps = 40):
        """!Streams frames for approximately n/fps seconds.
        
        The chip is set up to stream fps frames per second, streaming is started
        and sampled for n/fps seconds. Chips settings are not checked, so make
        sure that the given fps is possible.
        
        Returns:
            Array of normalized frames
        """
        
        q = self.start_streaming(fps = fps, len = n*2)
        sleep(1.0*n/fps)
        self.stop_streaming()
        frames = array(q.queue)/self._nfactor+self._noffset
        
        self.log.info("Sampled %d frames, goal was %d"%(len(frames), n))
        
        return frames
        
        
    def start_streaming(self, fps = 40, len=50):
        """!Starts streaming with given settings to a queue.
        
        The queue will discard frames without notice if it fills up to the given
        length.
        
        Parameters:
            fps - fps to stream frames. Not controlled.
            len - length of queue.
        
        Returns:
            An active frame streaming queue
        """ 

        q = DiscardingFrameQueue(len)
        self.radar.set_fps(0)
        
        if self.reg.rx_downconversion_enable:
            self.set_iq_frame_buffer(q)
        else:
            self.set_frame_buffer(q)
            
        self.radar.set_fps(fps)
        
        return q
    
    def stop_streaming(self):
        """!Stops streaming.
        """
        self.radar.set_fps(0)
    
    def set_tx_region(self, region):
        """! Sets tx center frequency based on region.
        
        Parameters:
            region:
                'eu'  - 7.290 GHz (EU / US)
                'kcc' - 8.748 GHz (KCC)
        """
        
        if region == 'eu':
            reg = 3
        elif region == 'kcc':
            reg = 4
        else:
            X4DriverError("Available regions are eu or kcc. %s is not a valid choice"%region)

        self.reg.tx_pll_fbdiv = reg

    
    
    
    
    
    
    
        
""" pyradarlib4 module

>>> # Calling PyRadarlib without arguments opens a "dummy" connection
>>> # Send the com-port name as a string to actually open the channel
>>> r = PyRadarlib4('dummy')
>>> # Enabling shadow registers lets us test some superficial things without
>>> # a real connection, not intended to be used in actual settings
>>> # This will generate warning messages that we will ignore here
>>> r.reg.set_use_shadow(True)
>>> r.reg.chip_id_sys
90
>>> # Writing to readonly registers yields an exception
>>> r.reg.chip_id_sys = 3
Traceback (most recent call last):
  ...
RegmapError: 'Attempted to write to a readonly segment'
>>> r.reg.xosc_en = 1
>>> # Writing a value thats bigger than the segment size also yields an exception
>>> r.reg.xosc_en = 2
Traceback (most recent call last):
  ...
RegmapError: 'Attempted to set a 1 bit register segment to 2.'
>>> r.reg.xosc_en
1
"""

import regmap
from __version__ import __version__
from radarphy import RadarPhyFactory
from radarnetwork import RadarNetwork
from radardefinitions import IoportDirection, PifAddr, IoportValue, IoportPinIndex, X4IoPins, IoportMode, SpiAddr
import logging
from time import sleep

FORMAT = "%(levelname)s:%(name)s: %(message)s"
logging.basicConfig(format=FORMAT)
logger = logging.getLogger("pyradarlib4")
logger.setLevel(logging.DEBUG)

EMBEDDED_FIRMWARE_XIF = [2, 0, 14, 0, 0, 0, 128, 251, 18, 0, 26, 18, 0, 3, 117, 208, 0, 117, 129, 191, 83, 146, 248, 2,
                         0, 8, 5, 129, 5, 129, 168, 129, 118, 0, 118, 0, 117, 128, 7, 128, 14, 229, 210, 162, 225, 80,
                         250, 8, 166, 211, 230, 240, 117, 212, 0, 229, 210, 162, 225, 80, 250, 24, 166, 211, 229, 210,
                         162, 225, 80, 250, 8, 166, 211, 230, 24, 112, 5, 230, 84, 127, 128, 3, 230, 68, 128, 83, 146,
                         248, 245, 130, 117, 131, 128, 230, 162, 231, 64, 199, 8, 224, 246, 134, 212, 128, 206]
EMBEDDEDFWOTP = [2, 254, 47, 0, 0, 0, 128, 251, 228, 121, 140, 120, 4, 184, 0, 2, 128, 4, 247, 9, 216, 252, 120, 33,
                 144, 254, 59, 122, 107, 186, 0, 2, 128, 7, 228, 147, 163, 246, 8, 218, 249, 18, 254, 166, 18, 254, 3,
                 117, 208, 0, 117, 129, 191, 83, 146, 248, 2, 254, 8, 2, 0, 14, 0, 0, 0, 128, 251, 18, 0, 26, 18, 0, 3,
                 117, 208, 0, 117, 129, 191, 83, 146, 248, 2, 0, 8, 5, 129, 5, 129, 168, 129, 118, 0, 118, 0, 117, 128,
                 7, 128, 14, 229, 210, 162, 225, 80, 250, 8, 166, 211, 230, 240, 117, 212, 0, 229, 210, 162, 225, 80,
                 250, 24, 166, 211, 229, 210, 162, 225, 80, 250, 8, 166, 211, 230, 24, 112, 5, 230, 84, 127, 128, 3,
                 230, 68, 128, 83, 146, 248, 245, 130, 117, 131, 128, 230, 162, 231, 64, 199, 8, 224, 246, 134, 212,
                 128, 206, 105, 0, 120, 140, 118, 0, 8, 118, 0, 120, 140, 121, 138, 195, 230, 151, 8, 9, 230, 151, 80,
                 53, 120, 140, 134, 8, 8, 134, 9, 229, 8, 36, 33, 248, 230, 120, 142, 83, 146, 248, 134, 130, 8, 134,
                 131, 240, 120, 142, 134, 130, 8, 134, 131, 163, 120, 142, 166, 130, 8, 166, 131, 120, 140, 230, 36, 1,
                 246, 8, 230, 52, 0, 246, 24, 128, 190, 117, 222, 0, 117, 247, 1, 117, 247, 1, 122, 0, 123, 0, 34]


class RadarLibError(Exception):
    """! Represent an exception that occurred in the Link layer
    """

    def __init__(self, value):
        self.value = value

    def __str__(self):
        return repr(self.value)


class IoPin(object):
    def __init__(self, radar, pin):
        self.pin = pin
        self.radar = radar

    def setMode(self, value):
        self.radar.set_io_pin_mode(self.pin, value)

    def setEnable(self):
        self.radar.set_io_pin_enable(self.pin)

    def setDisable(self):
        self.radar.set_io_pin_disable(self.pin)

    def setHigh(self):
        self.radar.set_io_pin_dir(self.pin, IoportDirection.IOPORT_DIR_OUTPUT)
        self.radar.set_io_pin_value(self.pin, IoportValue.IOPORT_PIN_LEVEL_HIGH)

    def setLow(self):
        self.radar.set_io_pin_dir(self.pin, IoportDirection.IOPORT_DIR_OUTPUT)
        self.radar.set_io_pin_value(self.pin, IoportValue.IOPORT_PIN_LEVEL_LOW)

    def setInput(self):
        self.radar.set_io_pin_dir(self.pin, IoportDirection.IOPORT_DIR_INPUT)

    def setOutput(self):
        self.radar.set_io_pin_dir(self.pin, IoportDirection.IOPORT_DIR_OUTPUT)

    def getVal(self):
        return self.radar.get_io_pin_value(self.pin)


class X4ABiDirectionalAnalogSwitch(object):
    """
    TS3A5223RSWR :http://www.ti.com/lit/ds/symlink/ts3a5223.pdf
    SEL1    SEL2    COM1    COM2
    0       0       NC1     NC2
    1       1       NO1     NO2
    1       0       NO1     NC2
    0       1       NC1     NO2
    """

    def __init__(self, pins):
        self.pins = pins

    def conncectS70ToSram(self):
        pin1 = self.pins.QSPI_nSS_SEL1
        pin2 = self.pins.QSPI_nSS_SEL2
        pin1.setHigh()
        pin2.setHigh()

    def connectS70ToX4(self):
        pin1 = self.pins.QSPI_nSS_SEL1
        pin2 = self.pins.QSPI_nSS_SEL2
        pin1.setLow()
        pin2.setHigh()

    def connectX4ToSram(self):
        pin1 = self.pins.QSPI_nSS_SEL1
        pin2 = self.pins.QSPI_nSS_SEL2
        pin1.setHigh()
        pin2.setLow()

    def connectS70X4andSram(self):
        pin1 = self.pins.QSPI_nSS_SEL1
        pin2 = self.pins.QSPI_nSS_SEL2
        pin1.setLow()
        pin2.setLow()


class X4Pins(object):
    def __init__(self, radar, initialize=True):

        self.radar = radar
        self.initialize_pins = initialize
        self.initialize_pins_test = 0
        self.PCBA_REV_ID0 = IoPin(radar, IoportPinIndex.PIO_PD10_IDX)
        self.PCBA_REV_ID0.setInput()
        self.PCBA_REV_ID0.setMode(IoportMode.IOPORT_MODE_PULL_DOWN)
        self.PCBA_REV_ID1 = IoPin(radar, IoportPinIndex.PIO_PD11_IDX)
        self.PCBA_REV_ID1.setInput()
        self.PCBA_REV_ID1.setMode(IoportMode.IOPORT_MODE_PULL_DOWN)

        # test
        if self.PCBA_REV_ID0.getVal() == 1 and self.PCBA_REV_ID1.getVal() == 1:
            logger.info("Detected PCBA_REV_ID 1,1, configuring io pins to match XTMCU01")
            self.use_mcu02_setup = 0
        elif self.PCBA_REV_ID0.getVal() == 0 and self.PCBA_REV_ID1.getVal() == 0:
            logger.info("Detected PCBA_REV_ID 0,0, configuring io pins to match XTMCU02")
            self.use_mcu02_setup = 1
        else:
            logger.info("Detected PCBA_REV_ID %d,%d, configuring io pins to match XTMCU02",
                        (self.PCBA_REV_ID1.getVal(), self.PCBA_REV_ID1.getVal()))
            self.use_mcu02_setup = 1

        ## todo: test
        # self.QSPI_NSS = IoPin(radar,IoportPinIndex.PIO_PA11_IDX)
        self.QSPI_nSS_SEL1 = IoPin(radar, IoportPinIndex.PIO_PA27_IDX)
        self.QSPI_nSS_SEL2 = IoPin(radar, IoportPinIndex.PIO_PA28_IDX)
        self.QSPI_SPI_NSS = IoPin(radar, IoportPinIndex.PIO_PA11_IDX)
        self.QSPI_IO1_SPI_MISO = IoPin(radar, IoportPinIndex.PIO_PA12_IDX)
        self.QSPI_IO0_SPI_MOSI = IoPin(radar, IoportPinIndex.PIO_PA13_IDX)
        self.QSPI_SCLK_SPI_CLK = IoPin(radar, IoportPinIndex.PIO_PA14_IDX)
        self.X4OTPPROG_I05 = IoPin(radar, IoportPinIndex.PIO_PA26_IDX)  # must be  drivenactive high at boot
        self.QSPI_IO2 = IoPin(radar, IoportPinIndex.PIO_PA17_IDX)
        self.QSPI_IO3 = IoPin(radar, IoportPinIndex.PIO_PD31_IDX)

        if self.use_mcu02_setup == 1:
            self.X4ENABLE_nARST = IoPin(radar, IoportPinIndex.PIO_PA5_IDX)
            self.MCU02_USER_IO2 = IoPin(radar, IoportPinIndex.PIO_PA25_IDX)
            self.MCU02_USER_IO5 = IoPin(radar, IoportPinIndex.PIO_PA26_IDX)
            self.MCU02_USER_IO6 = IoPin(radar, IoportPinIndex.PIO_PA27_IDX)
            self.MCU02_USER_IO1 = IoPin(radar, IoportPinIndex.PIO_PA28_IDX)
            self.MCU02_USER_IO3 = IoPin(radar, IoportPinIndex.PIO_PA30_IDX)
            self.MCU02_USER_IO4 = IoPin(radar, IoportPinIndex.PIO_PA31_IDX)
            self.MCU02_USER_IO1.setInput()
            self.MCU02_USER_IO2.setInput()
            self.MCU02_USER_IO3.setInput()
            self.MCU02_USER_IO4.setInput()
            self.MCU02_USER_IO5.setInput()
            self.MCU02_USER_IO6.setInput()
            self.MCU02_USER_IO1.setEnable()
            self.MCU02_USER_IO2.setEnable()
            self.MCU02_USER_IO3.setEnable()
            self.MCU02_USER_IO4.setEnable()
            self.MCU02_USER_IO5.setEnable()
            self.MCU02_USER_IO6.setEnable()
            self.MCU02_USER_IO1.setMode(IoportMode.IOPORT_MODE_PULL_DOWN)
            self.MCU02_USER_IO2.setMode(IoportMode.IOPORT_MODE_PULL_DOWN)
            self.MCU02_USER_IO3.setMode(IoportMode.IOPORT_MODE_PULL_DOWN)
            self.MCU02_USER_IO4.setMode(IoportMode.IOPORT_MODE_PULL_DOWN)
            self.MCU02_USER_IO5.setMode(IoportMode.IOPORT_MODE_PULL_DOWN)
            self.MCU02_USER_IO6.setMode(IoportMode.IOPORT_MODE_PULL_DOWN)


        else:
            self.X4ENABLE_nARST = IoPin(radar, X4IoPins.X4ENABLE_nARST)
        self.UART2_SPI_MOSI = IoPin(radar, IoportPinIndex.PIO_PD15_IDX)  # RX2
        self.UART2_SPI_MISO = IoPin(radar, IoportPinIndex.PIO_PD16_IDX)  # TXD2
        self.UART2_SPI_CLK = IoPin(radar, IoportPinIndex.PIO_PD17_IDX)
        self.UART2_SPI_NSS = IoPin(radar, IoportPinIndex.PIO_PD19_IDX)

        self.X4_GPIO1 = IoPin(radar, X4IoPins.X4_GPIO1)
        self.X4_GPIO2 = IoPin(radar, X4IoPins.X4_GPIO2)
        self.X4TM_IO4 = IoPin(radar, X4IoPins.X4TM_IO4)

        # self.radar.set_io_pin_disable(IoportPinIndex.PIO_PA17_IDX)
        # self.radar.set_io_pin_disable(IoportPinIndex.PIO_PD31_IDX)


        # self.UART2_SPI_NSS.setHigh()
        # self.UART2_SPI_NSS.setEnable()
        # self.UART2_SPI_CLK = IoPin(radar,IoportPinIndex.PIO_PD_17_IDX)
        ##master mode test
        # self.QSPI_SPI_NSS.setInput()
        # self.QSPI_SPI_NSS.setEnable()




        if self.initialize_pins:
            self.X4OTPPROG_I05.setEnable()
            self.X4OTPPROG_I05.setOutput()
            self.X4OTPPROG_I05.setHigh()
            self.X4ENABLE_nARST.setEnable()
            self.X4ENABLE_nARST.setOutput()
            self.X4ENABLE_nARST.setLow()
            # self.X4ENABLE_nARST.setMode(IoportMode.IOPORT_MODE_PULL_DOWN)

            self.X4TM_IO4.setEnable()
            self.X4TM_IO4.setInput()
            self.X4TM_IO4.setMode(IoportMode.IOPORT_MODE_PULL_DOWN)

            self.X4_GPIO1.setEnable()
            # self.X4_GPIO1.setLow()
            self.X4_GPIO1.setInput()
            self.X4_GPIO1.setMode(IoportMode.IOPORT_MODE_PULL_DOWN)

            self.X4_GPIO2.setEnable()
            self.X4_GPIO2.setInput()
            self.X4_GPIO2.setMode(IoportMode.IOPORT_MODE_PULL_DOWN)

        if self.initialize_pins_test:
            self.X4ENABLE_nARST.setEnable()
            self.X4ENABLE_nARST.setLow()
            self.X4TM_IO4.setEnable()
            self.X4TM_IO4.setLow()
            self.X4_GPIO1.setEnable()
            self.X4_GPIO1.setLow()
            self.X4_GPIO2.setEnable()
            self.X4_GPIO2.setLow()


class PyRadarlib4(object):
    """ PyRadarlib4 class.

    Takes care of connection to the radar and provides functions for communication
    with the hardware.

    """

    def __init__(self, connect_string='auto', chip='nva5ic001'):
        self.dummy_test = False
        self.logger = logging.getLogger("pyradarlib4")
        self.firmware_sha = "fa682701c1a0bc85ea1bafb6ea004ee17763913d"
        self.firmware_version = "0.0.27"
        self.override_fw_version = False
        self.logger.setLevel(logging.INFO)
        self.initialize = True
        self.radar = None
        #self.reg = None
       # self.pins = None
        self.ldolist = ['dvdd_tx', 'avdd_tx', 'avdd_rx', 'dvdd_rx']

        self.logger.debug("This is pyRadarlib4 version %s" % __version__)

        if connect_string:
            self.open_radar(connect_string, chip)

    def x4_reset(self):
        # Set X4 ENABLE pin active low (starts in pull-down)
        self.pins.X4ENABLE_nARST.setLow()
        # Set X4 ENABLE pin high
        self.pins.X4ENABLE_nARST.setHigh()
        # Current consumption should be 2-3 mA

    def enable_ldo(self, ldostr, maxtries=16):
        if ldostr not in self.ldolist:
            raise RadarLibError('LDO must be one of ' + ' '.join(self.ldolist))

        reg_pg = ldostr + '_power_good'
        reg_dis = ldostr + '_disable'
        reg_tm = ldostr + '_testmode'
        reg_trim = ldostr + '_trim'
        # set testbus to 0 V (by means of agnd from the dvdd ldo)
        self.reg.dvdd_testmode = 5
        self.reg[reg_dis] = 0
        for i in range(maxtries):
            if self.reg[reg_pg] > 0:
                break

            a = self.reg[reg_trim]
            self.reg[reg_trim] = 0
            self.reg[reg_tm] = 13
            sleep(0.1 * i)
            self.reg[reg_tm] = 0
            self.reg[reg_trim] = a
            sleep(0.1 * i)

        # return testbus to Z
        self.reg.dvdd_testmode = 0

        pg_flag = self.reg[reg_pg]
        if pg_flag < 1:
            # workaround was unsuccessful, disable and give up
            self.reg[reg_dis] = 1
            # raise RadarLibError(reg_pg + ' did not start')
            # we return a value to comply with the previously 
            # defined interface, rather than throwing an exception

        return pg_flag

    def enable_avdd_rx(self):
        return self.enable_ldo('avdd_rx')

    def enable_dvdd_rx(self):
        return self.enable_ldo('dvdd_rx')

    def enable_avdd_tx(self):
        return self.enable_ldo('avdd_tx')

    def enable_dvdd_tx(self):
        return self.enable_ldo('dvdd_tx')

    def enable_all_ldos(self, ignore=False):
        # try to enable all LDOs which are currently disabled
        # ignore means dont give up if an LDO does not start
        # in this case the caller must check the power_good register
        # to determine success and take appropriate action 
        startlist = []
        for ldo in self.ldolist:
            if self.reg[ldo + '_disable'] > 0:
                startlist.append(ldo)
        for ldo in startlist:
            pg = self.enable_ldo(ldo)
            if pg < 1 and not ignore:
                # LDO did not start, revert all the LDOs we were supposed
                # to start and raise an exception
                for ldodis in startlist:
                    self.reg[ldodis + '_disable'] = 1
                raise RadarLibError(ldo + ' did not start')


    def setup_xosc(self):
        self.reg.xosc_dislvl = 0
        self.reg.xosc_en = 1
        # Check that the crystal oscillator is running OK:
        i = 0
        res = False
        while (not res):
            i = i + 1
            sleep(0.5e-3)
            res = self.reg.xosc_lock == 1
            self.logger.debug('XOSC lock (attempt %d): %s' % (i, res))
            if (i == 100):
                break

        if not res:
            raise RadarLibError("XOSC lock failed")
        else:
            self.logger.info('XOSC lock: %s' % (res))

        # Set system clock to xosc
        self.reg.sysclk_sel = 1

        return res

    def __exit__(self, *args):
        """
        For PEP 343:
        Called when object is destroyed when exiting with statement
        Makes sure the class cleans up after it self by stopping the
        firmware and closing the connection.
        """
        self.radar.set_fps(0)
        self.close()

    def get_cdf(self, dacmin=0, dacmax=2047, step=1, keep_dac_range=False):
        """ Read out a CDF from the chip
        
        Uses the pulsesperstep and iterations settings already applied to the radar object.
        Overrides the dac value settings and then sets them back to the original setting when
        finished.
        
        Note that it is recommended to set trx_phase_override=1 before reading a CDF.
        
        Arguments:
            dacmin         : Start DAC value
            dacmax         : Stop DAC value
            step           : DAC step value
            keep_dac_range : Leave dac sweep settings in sweep controller
        """
        try:
            from numpy import array, zeros
        except ImportError as e:
            self.logger.debug("You need numpy to use this function!")
            raise e

        if self.reg.trx_phase_override == 0:
            self.logger.debug("trx_phase_override is 0, it is recommended to set this to 1 before reading a CDF.")

        rangedac = range(dacmin, dacmax + 1, step)
        rangedac_n = len(rangedac)

        # cdf = #zeros((rangedac_n,1536))
        cdf_timestamp = zeros(rangedac_n)
        self.reg.trx_dac_override_enable = 1
        self.reg.trx_dac_override_load = 1

        trx_dac_max_h = self.reg.trx_dac_max_h
        trx_dac_max_l = self.reg.trx_dac_max_l
        trx_dac_min_h = self.reg.trx_dac_min_h
        trx_dac_min_l = self.reg.trx_dac_min_l

        if keep_dac_range == False:
            self.reg.trx_dac_max_h = 0
            self.reg.trx_dac_max_l = 0
            self.reg.trx_dac_min_h = 0
            self.reg.trx_dac_min_l = 0

        from Queue import Queue
        q = Queue()
        bytes_per_sample = self.reg.rx_counter_num_bytes
        self.set_frame_buffer(q, bytes_per_sample)
        self.radar.get_cdf(dacmin, dacmax, step)

        l_size = 0

        from time import sleep, time
        sleep(0.1)
        # timeout after 100 seconds
        max_range = 1000
        for i in range(0, max_range):
            if i == max_range - 1:
                raise RadarLibError("Get_cdf timeout")

            if q.qsize() == rangedac_n:
                break
            # l_size = q.qsize()
            sleep(0.1)

        for j in range(0, q.qsize()):
            cdf_f = q.get_nowait()
            if j == 0:
                samplers = len(cdf_f.data)
                cdf = zeros((rangedac_n, samplers))
            cdf[j] = cdf_f.data
            cdf_timestamp[j] = cdf_f.timestamp

        self.reg.trx_dac_override_enable = 0
        self.reg.trx_dac_override_load = 1

        self.reg.trx_dac_max_h = trx_dac_max_h
        self.reg.trx_dac_max_l = trx_dac_max_l
        self.reg.trx_dac_min_h = trx_dac_min_h
        self.reg.trx_dac_min_l = trx_dac_min_l

        return (cdf, cdf_timestamp)

    def sram_self_test(self, silent=False):
        """ Run SRAM Built-In-Self-Test on chip.
        
        This function executes the SRAM BIST built into the chip 
        and reports the status.
        
        It is important to note that this will invalidate the
        content of the SRAM, so the chip must be reinitialized
        (program memory must be re-programmed) after the test is run.
        
        If silent is false, the result is printed as the test is run.
        The function returns False if one or more of the tests fails, 
        otherwise it returns True.
        """
        
        if not silent: self.logger.info("Running self test on all SRAM blocks. Program memory content will be invalidated.")
            
        res = True
        
        # Enable Sampler RAM0 BIST
        self.pins.X4ENABLE_nARST.setLow()
        self.pins.X4ENABLE_nARST.setHigh()
        self.radar.spi_write(0x80|0x0C, [0x01])
        RAM0_STATUS = self.radar.spi_read(0x0D)
        print RAM0_STATUS
        if ((RAM0_STATUS & 0xfe) == 0x02):
            st = True if RAM0_STATUS == 0x03 else False
            res = res & st
            if not silent: self.logger.info("Sampler RAM0 BIST status: %s" % st)
        else:
            self.logger.error("An unexpected error occured during execution of Sampler RAM0 BIST. Chip returned 0x%x" % RAM0_STATUS)
            res = False
            
        # Enable Sampler RAM1 BIST
        self.pins.X4ENABLE_nARST.setLow()
        self.pins.X4ENABLE_nARST.setHigh()
        self.radar.spi_write(0x80|0x0C, [0x02])
        RAM1_STATUS = self.radar.spi_read(0x0D)
        if ((RAM1_STATUS & 0xfb) == 0x08):
            st = True if RAM1_STATUS == 0x0C else False
            res = res & st
            if not silent: self.logger.info("Sampler RAM1 BIST status: %s" % st)
        else:
            self.logger.error("An unexpected error occured during execution of Sampler RAM1 BIST. Chip returned 0x%x" % RAM1_STATUS)
            res = False
        
        # Enable progmem BIST
        self.pins.X4ENABLE_nARST.setLow()
        self.pins.X4ENABLE_nARST.setHigh()
        self.radar.spi_write(0x80|0x1B, [0x02])
        PROGMEM_STATUS = self.radar.spi_read(0x1C)
        if ((PROGMEM_STATUS & 0xfb) == 0x08):
            st = True if PROGMEM_STATUS == 0x0C else False
            res = res & st
            if not silent: self.logger.info("Program memory BIST status: %s" % st)
        else:
            self.logger.error("An unexpected error occured during execution of program memory BIST. Chip returned 0x%x" % PROGMEM_STATUS)
            res = False
            
        # Enable IRAM BIST
        self.pins.X4ENABLE_nARST.setLow()
        self.pins.X4ENABLE_nARST.setHigh()
        self.radar.spi_write(0x80|0x1B, [0x01])
        IRAM_STATUS = self.radar.spi_read(0x1C)
        if ((IRAM_STATUS & 0xfe) == 0x02):
            st = True if IRAM_STATUS == 0x03 else False
            res = res & st
            if not silent: self.logger.info("Internal memory BIST status: %s" % st)
        else:
            self.logger.error("An unexpected error occured during execution of internal memory BIST. Chip returned 0x%x" % IRAM_STATUS)
            res = False
            
        return res



    def disable_downconversion(self):
        """ Disable on-chip downconversion feature
        Note: This function resets following registers to default and :
        rx_ram_line_last_msb
        rx_ram_line_last_lsb
        rx_counter_num_bytes
        """
        import numpy as np

        self.reg.rx_downconversion_enable = 0



        ######################################
        # Setup memory
        ######################################

        # First 4 rows are empty
        # -1 because we are including first and last line

        # for now set rx ram line last to default when disable.

        self.reg.rx_ram_line_last_msb = 0xBF
        self.reg.rx_ram_line_last_lsb = 0x01
        self.reg.rx_counter_num_bytes = 3

        # In downconversion mode num_lines == num_samples since one line stores I and Q
        # num_samples = num_lines
        # Fine settings controls how much of the sampled frame to actually store in SRAM
        # Sets the frame length in increments of microframes (=12 range bins)
        self.reg.rx_mframes = self.reg.rx_mframes_coarse * 96 / 12
        # Tell the FW to only read the specified number of bytes
        nrangebins = self.reg.rx_mframes_coarse  * 96
        self.radar.set_fw_frame_size(nrangebins * self.reg.rx_counter_num_bytes)


    def enable_downconversion(self, region='auto'):
        """ Enable on-chip downconversion feature
        
        This function programs the chip with the coefficient sets required
        to enable the onchip downconversion feature.

        Set region to 'eu' or 'kcc' depending on the center frequency
        of the transmitter:
          'auto': Automatically set filter coefficients to match transmitter configuration
          'eu'  : tx_pll_fbdiv should be 3
          'kcc' : tx_pll_fbdiv should be 4
        """
        import numpy as np

        self.reg.rx_downconversion_enable = 1

        # Default coefficients
        # See IC-1203        
        c1_i = np.array(
            [0, 1, -3, 0, 6, -7, -3, 16, -10, -13, 24, -5, -25, 25, 6, -31, 17, 16, -27, 6, 18, -16, -2, 12, -6, -3, 5,
             -1, -1, 1])
        c1_q = np.array(
            [1, -1, -1, 5, -3, -6, 12, -2, -16, 18, 6, -27, 16, 17, -31, 6, 25, -25, -5, 24, -13, -10, 16, -3, -7, 6, 0,
             -3, 1, 0])
        if region == 'auto':
            if self.reg.tx_pll_fbdiv == 3:
                region = 'eu'
            elif self.reg.tx_pll_fbdiv == 4:
                region = 'kcc'
            else:
                self.logger.warning('Unsupported transmitter configuration, unable to enable downconversion')
                return
        if region == 'eu':
            c2_i = -c1_i
            c2_q = -c1_q
        elif region == 'kcc':
            c2_i = c1_i
            c2_q = c1_q

        ######################################
        # Program coefficients
        ######################################
        for i in range(31, -1, -1):
            if i >= len(c1_i):
                self.reg.rx_downconversion_coeff_i1 = 0
            else:
                self.reg.rx_downconversion_coeff_i1 = 0x3f & c1_i[i]

        for i in range(31, -1, -1):
            if i >= len(c1_q):
                self.reg.rx_downconversion_coeff_q1 = 0
            else:
                self.reg.rx_downconversion_coeff_q1 = 0x3f & c1_q[i]

        for i in range(31, -1, -1):
            if i >= len(c2_q):
                self.reg.rx_downconversion_coeff_q2 = 0
            else:
                self.reg.rx_downconversion_coeff_q2 = 0x3f & c2_q[i]

        for i in range(31, -1, -1):
            if i >= len(c2_i):
                self.reg.rx_downconversion_coeff_i2 = 0
            else:
                self.reg.rx_downconversion_coeff_i2 = 0x3f & c2_i[i]

        ######################################
        # Setup memory
        ######################################         
        num_lines = ((128 * 12) / 8) - 4
        # First 4 rows are empty
        rx_ram_line_first = self.reg.rx_ram_write_offset_lsb + (self.reg.rx_ram_write_offset_msb << 8)
        # -1 because we are including first and last line
        rx_ram_line_last = rx_ram_line_first + num_lines - 1

        # radar.reg.rx_ram_line_first_lsb = rx_ram_line_first & 1
        # radar.reg.rx_ram_line_first_msb = (rx_ram_line_first >> 1) & 255
        self.reg.rx_ram_line_last_msb = (int(rx_ram_line_last) >> 1) & 255
        self.reg.rx_ram_line_last_lsb = int(rx_ram_line_last) & 1

        # Todo: We might want to be able to change this 
        self.reg.rx_counter_num_bytes = 6
        num_bytes = self.reg.rx_counter_num_bytes * 2 * num_lines

        # In downconversion mode num_lines == num_samples since one line stores I and Q
        # num_samples = num_lines
        self.set_fw_frame_size(num_bytes)

    def set_frame_buffer(self, buffer, bytes_per_sampler=None):
        if self.radar:
            if bytes_per_sampler == None:
                bytes_per_sampler = self.reg.rx_counter_num_bytes
            self.radar.link.set_frame_buffer(buffer, iq=False, bytes_per_sampler=bytes_per_sampler)

    def set_iq_frame_buffer(self, buffer):
        if self.radar:
            # todo implemnent uniform way of adding bytes per sampler.
            # iq frame currently does not use bytes per sampler
            self.radar.link.set_frame_buffer(buffer, iq=True, bytes_per_sampler=3)

    def close(self):
        self.radar.close()

    def open_radar(self, connect_string, chip):
        """ Connect to a radar on the serial port describe by connectString
          @param chip: chip to use
          @param connect_string: connection string for radar
        """

        if connect_string == "dummy":
            self.dummy_test = True
            self.logger.info("No connect string, skipping connection")
            # Skip connection, we're just testing
        else:
            self.logger.info("Connecting to %s" % connect_string)
            phy = RadarPhyFactory.getconnection(connect_string)
            self.radar = RadarNetwork(phy)
            if not self.override_fw_version:
                self.check_s70fw_version()

            self.pins = X4Pins(self.radar, self.initialize)


            # Connect to radar

        if chip == 'nva5ic001':
            self.reg = regmap.NVA5IC001(self, configfile_section_name="x4registers")
            if self.dummy_test == False and self.initialize == True:
                self.radar.set_spi_mode(0)
                self.radar.set_spi_speed(pow(10, 6) * 50)
                self.reg.spi_mode = 0
                # readback test
                self.pins.X4ENABLE_nARST.setHigh()
                self.reg.spi.debug = 0x55
                if self.reg.spi.debug != 0x55:
                    logger.info("Failed to readback SPI debug register at 50 Mhz. Switching to 30 Mhz.")
                    logger.info("Hardware is disconnected or using hardware not supporting 50 Mhz SPI.")
                    self.radar.set_spi_speed(pow(10, 6) * 30)
                self.pins.X4ENABLE_nARST.setLow()


        else:
            self.logger.fatal("Unknown chip %s" % chip)

    def check_s70fw_version(self):
        fw_version = self.radar.get_product()
        if not self.firmware_sha in fw_version:
            raise RadarLibError("Version in firmware does not match the expected sha.\n"
                                "Got %s \n"
                                "Expected SHA: %s\nExpected version: %s " % (
                                    fw_version, self.firmware_sha, self.firmware_version))

    def printVersions(self):
        fw_version = self.radar.get_product()
        okstr = "NOK"
        if self.firmware_sha in fw_version:
            okstr = "OK"
        logger.info("FW version is %s " % fw_version)
        logger.info("FW version is %s " % okstr)
        logger.info("Pyradarlib is %s " % __version__)

    def program_otp_memory(self, data, lsb, msb):
        """
        programs OTP memory. Programming is done on the XTMCU to avoid setting the OTPPROG pin low too long.
        @param data: data to program.
        @param lsb: least significant byte of address 0x00-0xFF
        @param msb: most significant byte of address 0xFE - OxFF
        @return:
        """
        if not self.dummy_test:
            if msb > 0xFF or msb < 0xFE:
                raise RadarLibError("Invalid value for msb. Valid range is 0xFE-0xFF")

            if lsb > 0xFF:
                raise RadarLibError("Invalid value for lsb Valid range is 0x00-0xFF")
            self.reg.spi.mem_first_addr_lsb = lsb
            self.reg.spi.mem_first_addr_msb = msb
            self.radar.program_otp(data)

    def set_pif_register(self, address, value):
        if not self.dummy_test:
            self.radar.pif_write_reg(address, value)
        self.logger.debug("Setting PIF register at address %s to %s" % (address, value))
        return 0

    def set_xif_register(self, address, value):
        if not self.dummy_test:
            self.radar.xif_write(address, value)
        self.logger.debug("Setting XIF register at address %s to %s" % (address, value))
        return 0

    def set_spi_register(self, address, value):
        if not self.dummy_test:
            self.radar.spi_write(address, value)
        self.logger.debug("Setting SPI register at address %s to %s" % (address, value))
        return 0

    def get_pif_register(self, address):
        self.logger.debug("Getting PIF register value at address %s" % address)
        value = None
        if not self.dummy_test:
            value = self.radar.pif_read_reg(address)


        return value

    def get_xif_register(self, address):
        self.logger.debug("Getting XIF register value at address %s" % address)
        value = None
        if not self.dummy_test:
            value = self.radar.xif_read(address)
        return value

    def get_spi_register(self, address):
        self.logger.debug("Getting SPI register value at address %s" % address)
        value = None
        if not self.dummy_test:
            value = self.radar.spi_read(address)
        return value

    def set_fw_frame_size(self, value):
        if not self.dummy_test:
            self.radar.set_fw_frame_size(value)

    def sample_frame(self, number_of_bytes_per_sample=None):
        value = None
        if not self.dummy_test:
            if number_of_bytes_per_sample == None:
                number_of_bytes_per_sample = self.reg.rx_counter_num_bytes
            value = self.radar.get_raw_frame_buffer(iq=False, number_of_bytes_per_sample=number_of_bytes_per_sample)
        return value

    def sample_iq_frame(self):
        value = None
        if not self.dummy_test:
            value = self.radar.get_raw_frame_buffer(iq=True)
        return value

    def trigger_single_radar_frame(self):
        self.radar.spi_write(SpiAddr.SPI_SPI_RADAR_DATA_CLEAR_STATUS_ADDR, 0xff)
        self.radar.pif_write(PifAddr.PIF_TRX_CLOCKS_PER_PULSE_ADDR, 0x02)
        self.radar.pif_write(PifAddr.PIF_TRX_PULSES_PER_STEP_MSB_ADDR, 0x00)
        self.radar.pif_write(PifAddr.PIF_TRX_PULSES_PER_STEP_LSB_ADDR, 0xff)
        self.radar.pif_write(PifAddr.PIF_RX_COUNTER_NUM_BYTES_ADDR, 0x03)
        self.radar.pif_write(PifAddr.PIF_RX_RESET_COUNTERS_ADDR, 0x01)
        self.radar.pif_write(PifAddr.PIF_TRX_START_ADDR, 0x01)
        trx_done = self.radar.pif_read(PifAddr.PIF_TRX_CTRL_DONE_ADDR)
        while trx_done & 1 == 0:
            # todo: add timeout
            trx_done = self.radar.pif_read(PifAddr.PIF_TRX_CTRL_DONE_ADDR)

        trx_backend_done = self.radar.pif_read(PifAddr.PIF_TRX_BACKEND_DONE_ADDR)
        while trx_backend_done & 1 == 0:
            # todo: add timeout
            trx_backend_done = self.radar.pif_read(PifAddr.PIF_TRX_BACKEND_DONE_ADDR)

        ram_select = self.radar.pif_read(PifAddr.PIF_RAM_SELECT_ADDR)
        if ram_select == 0x01:
            self.radar.pif_write(PifAddr.PIF_RAM_SELECT_ADDR, 0x00)
        else:
            self.radar.pif_write(PifAddr.PIF_RAM_SELECT_ADDR, 0x01)

        if self.radar.pif_read(PifAddr.PIF_RAM_SELECT_ADDR) == ram_select:
            raise RadarLibError("Bad register readback")

    def read_single_radar_frame(self, expected_radar_size=4608):

        self.radar.pif_write(SpiAddr.SPI_SPI_RADAR_DATA0_CLEAR_STATUS_ADDR, 0xff)
        self.radar.pif_write(SpiAddr.SPI_SPI_RADAR_DATA1_CLEAR_STATUS_ADDR, 0xff)
        self.radar.pif_write(SpiAddr.SPI_SPI_RADAR_DATA_CLEAR_STATUS_ADDR, 0xff)

        self.radar.pif_write(PifAddr.PIF_FETCH_RADAR_DATA_SPI_ADDR, 0xff)

        radar_data_status_spi = self.radar.spi_read(SpiAddr.SPI_RADAR_DATA_SPI_STATUS_ADDR)
        retries_max = 10
        retries = 0
        while radar_data_status_spi & 0x01 != 0:
            radar_data_status_spi = self.radar.spi_read(SpiAddr.SPI_RADAR_DATA_SPI_STATUS_ADDR)
            retries += 1
            if retries_max < retries:
                raise RadarLibError("Unresponsive register readback")

        tx_data = [SpiAddr.SPI_RADAR_DATA_SPI_ADDR]
        radar_data = self.radar.spi_rw_n(expected_radar_size, tx_data)

        max_data = len(radar_data)

        # convert to 24 bit ints
        idata = []
        for i in range(max_data / 3):
            data = radar_data[3 * i:3 * (i + 1)]
            idata.append(data[0] | data[1] << 8 | data[2] << 16)
        return idata

    def verify_8051(self, data):
        self.logger.debug("Verifying 8051 program data")
        self.radar.spi_write(SpiAddr.SPI_MEM_FIRST_ADDR_LSB, 0)  # lsb
        self.radar.spi_write(SpiAddr.SPI_MEM_FIRST_ADDR_MSB, 0)  # msb
        self.radar.spi_write(SpiAddr.SPI_MEM_MODE, 0)  # no readback, empty fifo
        status = self.radar.spi_read(SpiAddr.SPI_SPI_MEM_FIFO_STATUS_ADDR)
        if status & 4:
            while status & 4:
                self.radar.spi_read(SpiAddr.SPI_FROM_MEM_READ_DATA_ADDR)
                status = self.radar.spi_read(SpiAddr.SPI_SPI_MEM_FIFO_STATUS_ADDR)

        self.radar.spi_write(SpiAddr.SPI_MEM_MODE, 2)  # mem readback mode
        mem_mode = self.radar.spi_read(SpiAddr.SPI_MEM_MODE)
        if mem_mode != 2:
            raise RadarLibError("Bad register readback")
        errors = 0
        status = self.radar.spi_read(SpiAddr.SPI_SPI_MEM_FIFO_STATUS_ADDR)
        if status & 4 == 0:
            logger.debug(status)
            raise RadarLibError("Bad register readback")

        for d in data:
            while self.radar.spi_read(SpiAddr.SPI_SPI_MEM_FIFO_STATUS_ADDR) & 4 == 0:
                sleep(0.1)
                logger.debug("data not ready")
            drb = self.radar.spi_read(SpiAddr.SPI_FROM_MEM_READ_DATA_ADDR)
            # print hex(drb)
            if drb != d:
                # logger.debug\
                print ("Readback ", hex(drb), " Excpected", hex(d), "\n")
                errors += 1
        logger.debug("Total errors: ", errors, "\n")
        if errors != 0:
            raise RadarLibError("Readback of 8051 program memory fail. %d errors." % errors)
        status = self.radar.spi_read(SpiAddr.SPI_SPI_MEM_FIFO_STATUS_ADDR)
        if status & 4 == 0:
            raise RadarLibError("Bad register readback")

        self.radar.spi_write(SpiAddr.SPI_MEM_MODE, 0)  # disable readback

    def program_8051(self, data):
        self.logger.debug("Programming 8051 program data")
        self.radar.spi_write(SpiAddr.SPI_MEM_FIRST_ADDR_LSB, 0)  # lsb
        self.radar.spi_write(SpiAddr.SPI_MEM_FIRST_ADDR_MSB, 0)  # msb

        self.radar.spi_write(SpiAddr.SPI_MEM_MODE, 1)  # mem programing mode
        # self.radar.spi_write(SpiAddr.SPI_MEM_MODE, 1)  # mem programing mode

        mem_mode = self.radar.spi_read(SpiAddr.SPI_MEM_MODE)

        if mem_mode != 1:
            raise RadarLibError("Bad register readback,val %d" % mem_mode)

        for d in data:

            while self.radar.spi_read(SpiAddr.SPI_SPI_MEM_FIFO_STATUS_ADDR) & 2 == 0:
                logger.debug("data not ready")
            self.radar.spi_write(SpiAddr.SPI_TO_MEM_WRITE_DATA_ADDR, d)  # data

    def programEmbedded8051Firmware(self):
        self.program_8051(EMBEDDED_FIRMWARE_XIF)
        # when programming the embedded firmware, it makes sense to set boot from otp to 0
        self.reg.spi.boot_from_otp_spi = 0
        self.verify_8051(EMBEDDED_FIRMWARE_XIF)


# When module is run as script, we're executing doctests
if __name__ == "__main__":
    import doctest

    # We only want to know if something went really wrong.
    logger.setLevel(logging.FATAL)
    doctest.testmod()

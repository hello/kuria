from radarutil import btoi
from radarlink import *

SPI_MIN = (150.0 / 255) * pow(10, 6)

SPI_MAX = 150 * pow(10, 6)

logging.basicConfig()

XTS_DEF_OK_RESP = bytearray([SerialFlagByte.XTS_FLAG_START, SerialProtocolResponse.XTS_SPR_REPLY,0])


def check_ok_resp(cmd,data):
    if data[:len(XTS_DEF_OK_RESP)] != XTS_DEF_OK_RESP:
        return False
    return data[len(XTS_DEF_OK_RESP)] == cmd

def _spi_reply_write_ok(message):
    return message[:len(ProtocolResponse.XTS_DEF_SPI_WRITE_OK)] == ProtocolResponse.XTS_DEF_SPI_WRITE_OK

def _spi_reply_read_ok(message):
    resp = bytearray([SerialFlagByte.XTS_FLAG_START, SerialProtocolResponse.XTS_SPR_REPLY,
                      SerialProtocolResponse.XTS_SPR_REPLY, XtsSdc.XTS_SDC_RADHW_SPI_READ])
    return message[:len(resp)] == resp


class RadarNetworkError(Exception):
    """! Represent an exception that occurred in the network layer of Radar stack
    """

    def __init__(self, value):
        self.value = value

    def __str__(self):
        return repr(self.value)



class SpiCounter(object):

    def __init__(self,max):
        self.max = max
        self.count = 0

    def increase(self):
        self.count += 1
        if self.count >= self.max:
            raise RadarNetworkError("SPI unresponsive exceeded max retires.")


class RadarNetwork(object):
    def __init__(self, phy, debug=False):
        """Initializes and opens a connection to a Radar.
        
        @param phy: interface to Radar .
        """

        self.logger = logging.getLogger('RadarNetwork')

        if debug:
            self.logger.setLevel("DEBUG")

        self.frame_buffers = Queue.Queue(1000)
        self.frame_sampling_timeout = 0
        self.link = RadarLink(phy)
        self.link.open()
        self.last_frame_timestamp = 0

    def __exit__(self, *args):
        """
        For PEP 343:
        Called when object is destroyed when exiting with statement
        Makes sure the class cleans up after it self by stopping the
        firmware and closing the connection.
        """
        self.close()

    def close(self):
        self.link.close()


    def get_last_frame_timestamp(self):
        return self.last_frame_timestamp
    def get_io_pin_value(self, pin):
        """
        Get the value of a
        """
        self.link.write_byte(SerialProtocolCommand.XTS_SPC_DIR_COMMAND)
        self.link.write_byte(XtsSdc.XTS_SDC_RADHW_GET_IO_VAL)
        self.link.write_byte(pin)
        self.link.flush()
        resp = self.link.getmessage()
        # TODO validation and test
        return resp.msg[3 + 4 + 4 + 4]

    def set_io_pin_value(self, pin, value):
        self.link.write_byte(SerialProtocolCommand.XTS_SPC_DIR_COMMAND)
        self.link.write_byte(XtsSdc.XTS_SDC_RADHW_SET_IO_VAL)
        self.link.write_byte(pin)
        self.link.write_byte(value)
        self.link.flush()
        resp = self.link.getmessage()
        # TODO  validation and test
        # return resp.msg[3+4+4+4]

    def set_io_pin_mode(self, pin, mode):
        self.link.write_byte(SerialProtocolCommand.XTS_SPC_DIR_COMMAND)
        self.link.write_byte(XtsSdc.XTS_SDC_RADHW_SET_IO_MODE)
        self.link.write_byte(pin)
        self.link.write_byte(mode)
        self.link.flush()
        resp = self.link.getmessage()
        # TODO  validation and test
        # return resp.msg[3+4+4+4]

    def set_io_pin_dir(self, pin, direction):
        self.link.write_byte(SerialProtocolCommand.XTS_SPC_DIR_COMMAND)
        self.link.write_byte(XtsSdc.XTS_SDC_RADHW_SET_IO_DIR)
        self.link.write_byte(pin)
        self.link.write_byte(direction)
        self.link.flush()
        resp = self.link.getmessage()
        # TODO  validation and test
        # return resp.msg[3+4+4+4]

    def set_io_pin_enable(self, pin):
        self.link.write_byte(SerialProtocolCommand.XTS_SPC_DIR_COMMAND)
        self.link.write_byte(XtsSdc.XTS_SDC_RADHW_ENABLE_IO_VAL)
        self.link.write_byte(pin)
        self.link.flush()
        resp = self.link.getmessage()
        # TODO  validation and test
        # return resp.msg[3+4+4+4]

    def set_io_pin_disable(self, pin):
        self.link.write_byte(SerialProtocolCommand.XTS_SPC_DIR_COMMAND)
        self.link.write_byte(XtsSdc.XTS_SDC_RADHW_DISABLE_IO_VAL)
        self.link.write_byte(pin)
        self.link.flush()
        resp = self.link.getmessage()
        # TODO  validation and test
        # return resp.msg[3+4+4+4]

    def _pif_read_spi2pif(self, address):

        fifo_status = self.spi_read(SpiAddr.SPI_SPI_MB_FIFO_STATUS_ADDR)
        while fifo_status & 2 == 2:
            fifo_status = self.spi_read(SpiAddr.SPI_SPI_MB_FIFO_STATUS_ADDR)
            self.spi_read(SpiAddr.SPI_FROM_CPU_READ_DATA_ADDR)  # empty fifo
            print "emptying fifo"
        self.spi_write(SpiAddr.SPI_TO_CPU_WRITE_DATA_ADDR, address)
        retries_max = 10
        retries = 0
        while fifo_status & 2 == 0:
            fifo_status = self.spi_read(SpiAddr.SPI_SPI_MB_FIFO_STATUS_ADDR)
            print "waiting for pif data,retries %d, max %d" % (retries, retries_max)
            retries += 1
            if retries_max == retries:
                raise Exception("SPI_PIF FAIL")
        return self.spi_read(SpiAddr.SPI_FROM_CPU_READ_DATA_ADDR)
        # todo test

    def _pif_write_spi2pif(self, address, value):
        address |= 0x80
        # TODO: refactor mailbox checking to seperate function and add option of checking mailbox.
        # will never fill mailbox as is due to slow reponse of uc
        retries = 0
        retries_max = 10
        # check mailbox full
        fifo_status = self.spi_read(SpiAddr.SPI_SPI_MB_FIFO_STATUS_ADDR)
        while fifo_status & 4 == 0:
            fifo_status = self.spi_read(SpiAddr.SPI_SPI_MB_FIFO_STATUS_ADDR)
            print "Waiting for cpu to read data"
            retries += 1
            if retries > retries_max:
                raise Exception("SPI_PIF FAIL")

        self.spi_write(SpiAddr.SPI_TO_CPU_WRITE_DATA_ADDR, address)

        # check mailbox
        fifo_status = self.spi_read(SpiAddr.SPI_SPI_MB_FIFO_STATUS_ADDR)
        while fifo_status & 4 == 0:
            fifo_status = self.spi_read(SpiAddr.SPI_SPI_MB_FIFO_STATUS_ADDR)
            print "Waiting for cpu to read data"
            retries += 1
            if retries > retries_max:
                raise Exception("SPI_PIF FAIL")

        self.spi_write(SpiAddr.SPI_TO_CPU_WRITE_DATA_ADDR, value)

        while fifo_status & 4 == 0:
            fifo_status = self.spi_read(SpiAddr.SPI_SPI_MB_FIFO_STATUS_ADDR)
            print "Waiting for cpu to read data"
            retries += 1
            if retries > retries_max:
                raise Exception("SPI_PIF FAIL")
                # todo test

    def xif_write(self, address, value):
        address |= 0x80
        # TODO: refactor mailbox checking to seperate function and add option of checking mailbox.
        # will never fill mailbox as is due to slow reponse of uc
        retries = 0
        retries_max = 10
        # check mailbox full
        fifo_status = self.spi_read(SpiAddr.SPI_SPI_MB_FIFO_STATUS_ADDR)
        while fifo_status & 4 == 0:
            fifo_status = self.spi_read(SpiAddr.SPI_SPI_MB_FIFO_STATUS_ADDR)
            self.logger.info("Waiting for cpu to read data")
            retries += 1
            if retries > retries_max:
                raise RadarNetworkError("SPI_PIF FAIL")


        self.spi_write(SpiAddr.SPI_TO_CPU_WRITE_DATA_ADDR, address)
        self.spi_write(SpiAddr.SPI_TO_CPU_WRITE_DATA_ADDR, 0x01)  # xif command
        # check mailbox
        fifo_status = self.spi_read(SpiAddr.SPI_SPI_MB_FIFO_STATUS_ADDR)
        while fifo_status & 4 == 0:
            fifo_status = self.spi_read(SpiAddr.SPI_SPI_MB_FIFO_STATUS_ADDR)
            self.logger.info("Waiting for cpu to read data")
            retries += 1
            if retries > retries_max:
                raise RadarNetworkError("SPI_XIF FAIL")

        self.spi_write(SpiAddr.SPI_TO_CPU_WRITE_DATA_ADDR, value)

        while fifo_status & 4 == 0:
            fifo_status = self.spi_read(SpiAddr.SPI_SPI_MB_FIFO_STATUS_ADDR)
            self.logger.info("Waiting for cpu to read data")
            retries += 1
            if retries > retries_max:
                raise RadarNetworkError("Xif interface not responding.")
                # todo test

    def xif_read(self, address):

        fifo_status = self.spi_read(SpiAddr.SPI_SPI_MB_FIFO_STATUS_ADDR)

        spi_cnt = SpiCounter(20)
        while fifo_status & 2 == 2:
            fifo_status = self.spi_read(SpiAddr.SPI_SPI_MB_FIFO_STATUS_ADDR)
            self.spi_read(SpiAddr.SPI_FROM_CPU_READ_DATA_ADDR)  # empty fifo
            self.logger.info("emptying fifo")
            spi_cnt.increase()
        self.spi_write(SpiAddr.SPI_TO_CPU_WRITE_DATA_ADDR, address)

        self.spi_write(SpiAddr.SPI_TO_CPU_WRITE_DATA_ADDR, 0x01)  # pif command
        retries_max = 10
        retries = 0
        while fifo_status & 2 == 0:
            fifo_status = self.spi_read(SpiAddr.SPI_SPI_MB_FIFO_STATUS_ADDR)
            self.logger.info( "waiting for xif data,retries %d, max %d" % (retries, retries_max))
            retries += 1
            if retries_max == retries:
                raise RadarNetworkError("Xif interface not responding.")
        return self.spi_read(SpiAddr.SPI_FROM_CPU_READ_DATA_ADDR)
        # todo test

    def pif_write(self, address, value):
        address |= 0x80
        # TODO: refactor mailbox checking to seperate function and add option of checking mailbox.
        # will never fill mailbox as is due to slow reponse of uc
        retries = 0
        retries_max = 10
        # check mailbox full
        fifo_status = self.spi_read(SpiAddr.SPI_SPI_MB_FIFO_STATUS_ADDR)
        while fifo_status & 4 == 0:
            fifo_status = self.spi_read(SpiAddr.SPI_SPI_MB_FIFO_STATUS_ADDR)
            self.logger.info("Waiting for cpu to read data")
            retries += 1
            if retries > retries_max:
                raise RadarNetworkError("Pif interface not responding.")

        self.spi_write(SpiAddr.SPI_TO_CPU_WRITE_DATA_ADDR, address)
        self.spi_write(SpiAddr.SPI_TO_CPU_WRITE_DATA_ADDR, 0x00)  # pif command
        # check mailbox
        fifo_status = self.spi_read(SpiAddr.SPI_SPI_MB_FIFO_STATUS_ADDR)
        while fifo_status & 4 == 0:
            fifo_status = self.spi_read(SpiAddr.SPI_SPI_MB_FIFO_STATUS_ADDR)
            self.logger.info("Waiting for cpu to read data")
            retries += 1
            if retries > retries_max:
                raise RadarNetworkError("Pif interface not responding.")
        self.spi_write(SpiAddr.SPI_TO_CPU_WRITE_DATA_ADDR, value)

        while fifo_status & 4 == 0:
            fifo_status = self.spi_read(SpiAddr.SPI_SPI_MB_FIFO_STATUS_ADDR)
            self.logger.info( "Waiting for cpu to read data")
            retries += 1
            if retries > retries_max:
                raise RadarNetworkError("Pif interface not responding.")
                # todo test

    def pif_read(self, address):

        fifo_status = self.spi_read(SpiAddr.SPI_SPI_MB_FIFO_STATUS_ADDR)
        spi_cnt = SpiCounter(20)
        while fifo_status & 2 == 2:
            self.spi_read(SpiAddr.SPI_FROM_CPU_READ_DATA_ADDR)  # empty fifo
            fifo_status = self.spi_read(SpiAddr.SPI_SPI_MB_FIFO_STATUS_ADDR)
            self.logger.info( "emptying fifo")
            spi_cnt.increase()
        self.spi_write(SpiAddr.SPI_TO_CPU_WRITE_DATA_ADDR, address)

        self.spi_write(SpiAddr.SPI_TO_CPU_WRITE_DATA_ADDR, 0x00)  # pif command
        retries_max = 10
        retries = 0
        while fifo_status & 2 == 0:
            fifo_status = self.spi_read(SpiAddr.SPI_SPI_MB_FIFO_STATUS_ADDR)
            self.logger.info( "waiting for pif data,retries %d, max %d" % (retries, retries_max))
            retries += 1
            if retries_max == retries:
                raise RadarNetworkError("Pif interface not responding.")
        return self.spi_read(SpiAddr.SPI_FROM_CPU_READ_DATA_ADDR)


    def spi_write(self, addr, value):
        """
        Writes directly on spi bus
        @param addr:
        @param value:
        @return:
        """
        self.link.write_byte(SerialProtocolCommand.XTS_SPC_DIR_COMMAND)
        self.link.write_byte(XtsSdc.XTS_SDC_RADHW_SPI_WRITE)
        addr |= 0x80
        self.link.write_byte(addr)
        self.link.write_byte(value)
        self.link.flush()
        aa = self.link.getmessage()
        if  _spi_reply_write_ok(aa.msg) == False:
            raise RadarNetworkError("Bad response from spi write cmd")

    def spi_read(self, address):
        """
        Reads directly on spi bus
        @param address: the address in spi registers
        """
        self.link.write_byte(SerialProtocolCommand.XTS_SPC_DIR_COMMAND)
        self.link.write_byte(XtsSdc.XTS_SDC_RADHW_SPI_READ)
        self.link.write_byte(address)

        self.link.flush()
        aa = self.link.getmessage()

        if not aa:
            self.link.print_state()
            raise RadarNetworkError("MCU unresponsive to XTS_SDC_RADHW_SPI_READ cmd")
        if not _spi_reply_read_ok(aa.msg):
            raise RadarNetworkError("Invalid response from spi read cmd")

        return aa.msg[3 + 4 + 4 + 4]


    def spi_write_reg(self, addr, value):
        """
        Writes directly on spi bus
        @param addr:
        @param value:
        @return:
        """
        self.link.write_byte(SerialProtocolCommand.XTS_SPC_DIR_COMMAND)
        self.link.write_byte(XtsSdc.XTS_SDC_RADHW_SPI_REG_WRITE)
        addr |= 0x80
        self.link.write_byte(addr)
        self.link.write_byte(value)
        self.link.flush()
        aa = self.link.getmessage()

        # todo: validate response


    def spi_read_reg(self, address):
        """
        Reads directly on spi bus
        @param address: the address in spi registers
        """
        self.link.write_byte(SerialProtocolCommand.XTS_SPC_DIR_COMMAND)
        self.link.write_byte(XtsSdc.XTS_SDC_RADHW_SPI_REG_READ)
        self.link.write_byte(address)

        self.link.flush()
        aa = self.link.getmessage()


        return aa.msg[3 + 4 + 4 + 4]


    def pif_read_reg(self, address):
        """
        Reads directly on spi bus
        @param address: the address in spi registers
        """
        self.link.write_byte(SerialProtocolCommand.XTS_SPC_DIR_COMMAND)
        self.link.write_byte(XtsSdc.XTS_SDC_RADHW_PIF_REG_READ)
        self.link.write_byte(address)

        self.link.flush()
        aa = self.link.getmessage()
        # todo: validate response
        if aa:
            if aa.get_status():
                raise Exception("Pif write fail. Fifo unresponsive. status = %s "%aa.get_status())
        else:
            raise Exception("Pif write fail. MCU unresponsive.")
        return aa.msg[3 + 4 + 4 + 4]


    def pif_write_reg(self, addr, value):
        """
        Writes directly on spi bus
        @param addr:
        @param value:
        @return:
        """
        self.link.write_byte(SerialProtocolCommand.XTS_SPC_DIR_COMMAND)
        self.link.write_byte(XtsSdc.XTS_SDC_RADHW_PIF_REG_WRITE)
        self.link.write_byte(addr)
        self.link.write_byte(value)
        self.link.flush()
        aa = self.link.getmessage()
        if aa:
            if aa.get_status():
                raise Exception("Pif read fail. Fifo unresponsive.")
        else:
            raise Exception("Pif read fail. MCU unresponsive.")
        #print aa.content_as_hex()
        # todo :validate response


    def spi_rw_n(self, n_rx, tx_data):
        """
        Writes directly on spi bus
        @param addr:
        @param value:
        @return:
        """
        self.link.write_byte(SerialProtocolCommand.XTS_SPC_DIR_COMMAND)
        self.link.write_byte(XtsSdc.XTS_SDC_RADHW_SPI_RW_N)
        self.link.write_uint32(n_rx)
        self.link.write_uint32(len(tx_data))
        for d in tx_data:
             self.link.write_byte(d)
        self.link.flush()
        aa = self.link.getmessage(timeout=5)
        if aa.msg[7] == 0xfd:
            raise Exception("MCU:Timeout,waiting for data")
       # print aa.content_as_hex()
        #print "startus", hex(aa.msg[3 + 4 + 4])

        return aa.msg[3 + 4 + 4 + 4:-1 ]
        #if  _spi_reply_write_ok(aa.msg) == False:
        #    raise RadarNetworkError("Bad response from spi write cmd")

    def program_otp(self, data):
        """
        Writes directly on spi bus
        @param addr:
        @param value:
        @return:
        """
        self.link.write_byte(SerialProtocolCommand.XTS_SPC_DIR_COMMAND)
        self.link.write_byte(XtsSdc.XTS_SDC_RADHW_PROG_OTP)

        self.link.write_uint32(len(data))
        for d in data:
            self.link.write_byte(d)
        self.link.flush()
        aa = self.link.getmessage()
        #return aa.msg[3 + 4 + 4 + 4:-1]
        # if  _spi_reply_write_ok(aa.msg) == False:
        #    raise RadarNetworkError("Bad response from spi write cmd")

    def prog8051(self):
        """
        """
        self.link.write_byte(SerialProtocolCommand.XTS_SPC_DIR_COMMAND)
        self.link.write_byte(XtsSdc.XTS_SDC_RADHW_PROG_8051)
        self.link.flush()
        aa = self.link.getmessage()
        #print aa.contentAsHex()
        # todo: validate response

    def verify8051(self):
        """
        """
        self.link.write_byte(SerialProtocolCommand.XTS_SPC_DIR_COMMAND)
        self.link.write_byte(XtsSdc.XTS_SDC_RADHW_VERIFY_8051)
        self.link.flush()
        aa = self.link.getmessage()
        errors =  btoi(aa.msg[15:15 + 4])
        #print aa.contentAsHex()
        return errors

    def get_clock(self,id=0):
        """
        """
        self.link.write_byte(SerialProtocolCommand.XTS_SPC_DIR_COMMAND)
        self.link.write_byte(XtsSdc.XTS_SDC_RADHW_GET_CLOCK)
        self.link.write_byte(int(id))
        self.link.flush()
        aa = self.link.getmessage()
        clock =  btoi(aa.msg[15:15 + 4])
        #print aa.contentAsHex()
        return clock

    def set_fps(self,fps):
        """
        """
        self.link.write_byte(SerialProtocolCommand.XTS_SPC_DIR_COMMAND)
        self.link.write_byte(XtsSdc.XTS_SDC_RADHW_SET_STREAM_FPS)
        self.link.write_uint32(int(fps))
        #i_allowed_frame_rate_deviance_percent = int(allowed_frame_rate_deviance_percent)
        #if i_allowed_frame_rate_deviance_percent < 1 or i_allowed_frame_rate_deviance_percent > 100:
        #    raise RadarNetworkError("Valid fps deviance settings are between 1 and 100 percent")
        #self.link.fps_deviance_allowed = i_allowed_frame_rate_deviance_percent
        #self.link.write_uint32(i_allowed_frame_rate_deviance_percent)
        self.link.flush()
        aa = self.link.getmessage()

        real_fps = self.get_real_fps()
        if fps != real_fps:
            self.logger.warn("Requested %d fps , actual fps %.32f"%(fps,real_fps))

        #todo verify response

    def get_real_fps(self,ticks_per_sec=1000):
        """
        returns the read fps configured on the S70
        @param ticks_per_sec: ticks per second on timer on the S70
        @return:
        """
        self.link.write_byte(SerialProtocolCommand.XTS_SPC_DIR_COMMAND)
        self.link.write_byte(XtsSdc.XTS_SDC_RADHW_GET_REAL_FPS)
        self.link.flush()
        aa = self.link.getmessage()
        ticks = btoi(aa.msg[15:15 + 4])
        
        if ticks == 0:
            real_fps = 0
        else:
            real_fps = 1/(float(ticks)/ticks_per_sec)
        return real_fps


    def set_spi_speed(self,speed):
        """
        """
        if speed < SPI_MIN or speed > SPI_MAX:
            raise RadarNetworkError("Valid speed settings for spi are %d mhz to %d mhz"% (SPI_MIN/pow(10,6),SPI_MAX/pow(10,6)))
        self.link.write_byte(SerialProtocolCommand.XTS_SPC_DIR_COMMAND)
        self.link.write_byte(XtsSdc.XTS_SDC_RADHW_SET_SPI_SPEED)
        self.link.write_uint32(int(speed))
        self.link.flush()
        aa = self.link.getmessage()
        #todo verify response

    def set_fw_frame_size(self,frame_size):
        """
        """
        self.link.write_byte(SerialProtocolCommand.XTS_SPC_DIR_COMMAND)
        self.link.write_byte(XtsSdc.XTS_SDC_RADHW_SET_FW_FRAME_SIZE)
        self.link.write_uint32(int(frame_size))
        self.link.flush()
        aa = self.link.getmessage()
        #todo verify response

    def set_spi_mode(self, mode):
        """
        """
        self.link.write_byte(SerialProtocolCommand.XTS_SPC_DIR_COMMAND)
        self.link.write_byte(XtsSdc.XTS_SDC_RADHW_SET_SPI_MODE)
        self.link.write_uint32(mode)
        self.link.flush()
        aa = self.link.getmessage()
        #todo verify response


    def set_sample_timeout(self,timeout_ms):
        """
        Sets sampletimeout with milisecond resolution
        max value is 2^64
        min value is 1
        value 0 disables timeout check
        @param timeout_ms:
        @return:
        """

        self.link.write_byte(SerialProtocolCommand.XTS_SPC_DIR_COMMAND)
        self.link.write_byte(XtsSdc.XTS_SDC_RADHW_SET_SAMPLING_TIMEOUT)
        self.link.write_uint64(int(timeout_ms))
        self.frame_sampling_timeout = timeout_ms/1000 +3 ##seconds
        self.link.flush()
        aa = self.link.getmessage()

    def get_raw_frame_buffer(self, iq=False,number_of_bytes_per_sample=3):
        """
        """
        self.link.write_byte(SerialProtocolCommand.XTS_SPC_DIR_COMMAND)
        self.link.write_byte(XtsSdc.XTS_SDC_RADLIB_GETFRAMERAW)
        self.link.flush()
        timeout = 3
        if self.frame_sampling_timeout != 0:
            timeout = self.frame_sampling_timeout


        aa = self.link.getmessage(timeout=timeout)
        # print len(aa.msg)
        # print aa.content_as_hex()
        if not aa:
            raise RadarNetworkError("Failed to get frame from MCU.")
        else:
            status = int(aa.msg[6])
            #print aa.content_as_hex()

            if int(status) & 0x80 == 0x80:
                raise RadarNetworkError(
                    "Frame sampling timeout, adjust sampling timeout value or frame sampling settings.")
            timestamp_slice = aa.msg[7:7+8]
            from radarutil import  btol
            timestamp = btol(timestamp_slice)
            self.last_frame_timestamp = timestamp
            if iq:
                return unpack_iqframe(aa.msg[7+8:])
            else:
                # print "len aa.msg",len(aa.msg)
                # print aa.content_as_hex()
                # dropping end flag
                return unpack_frame2(aa.msg[7+8:],bytes_per_frame=number_of_bytes_per_sample)#unpack_frame(aa,0)

                

        #return aa.msg[3 + 4 + 4 + 4:-1]
        #todo verify response

    def get_cdf(self,min,max,step):
        """
        """
        self.link.write_byte(SerialProtocolCommand.XTS_SPC_DIR_COMMAND)
        self.link.write_byte(XtsSdc.XTS_SDC_RADHW_RUN_CDF)
        self.link.write_uint32(min)
        self.link.write_uint32(max)
        self.link.write_uint32(step)
        self.link.flush()
        aa = self.link.getmessage(timeout=0.1)
        # print len(aa.msg)
        # print aa.content_as_hex()
        #if not aa:
         #   raise RadarNetworkError("Failed to get frame from MCU.")

    def ping(self):
        """!Sends a ping to s70
        
        """
        self.link.write_byte(SerialProtocolCommand.XTS_SPC_PING)

        self.link.write_byte(0xae)
        self.link.write_byte(0xea)
        self.link.write_byte(0xaa)
        self.link.write_byte(0xee)
        self.link.flush()

        msg = self.link.getmessage()

        resp = msg.msg[2:6]

        if resp == ProtocolResponse.XTS_DEF_PONGVAL_READY:
            self.logger.debug("PING response: System ready")
            return True
        elif resp == ProtocolResponse.XTS_DEF_PONGVAL_NOTREADY:
            self.logger.debug("PING response: System NOT ready")
            return False
        else:
            self.logger.warning("PING response not recognized")
            return False

    def get_string_cmd(self,cmd):
        self.link.write_byte(SerialProtocolCommand.XTS_SPC_DIR_COMMAND)
        self.link.write_byte(cmd)
        self.link.flush()
        aa = self.link.getmessage()
        msg = aa.msg[3 + 4 + 4 + 4:-1]
        #print str(msg)
        return msg

    def get_version(self):
        return self.get_string_cmd(XtsSdc.XTS_SDC_SYSTEM_GET_VERSION)

    def get_build(self):
        return self.get_string_cmd(XtsSdc.XTS_SDC_SYSTEM_GET_BUILD)

    def get_product(self):
        return self.get_string_cmd(XtsSdc.XTS_SDC_SYSTEM_GET_PRODUCT)

# This is the Twisted Get Poetry Now! client, version 3.0.

# NOTE: This should not be used as the basis for production code.

import optparse
import struct
import unittest
import enum

from twisted.internet.protocol import Protocol, ClientFactory
from twisted.internet import reactor

class PacketType(enum.IntEnum):
    frame = 1
    command = 2
    response = 3
    framelength = 4

class PacketHandler:
    count = 0
    frame = False
    high = False;

    def __init__(self, sender):
        self.sender = sender

    def handle_packet(self, packet):
        sizeof_packet_id = 4
        if len(packet) < sizeof_packet_id:
            print "exiting"
            return
        packet_id_bytes = packet[:sizeof_packet_id]
        packet = packet[sizeof_packet_id:]
        packet_id, = struct.unpack("!I", packet_id_bytes)
        self.count += 1
        if self.frame == True:
            self.frame = False
            print "data: ", len(packet), " ", self.count
        else: # ok or nok
            print "got response"


        if self.count % 40 == 0:
            if self.high:
                self.high = False;
                payload = struct.pack('!I', PacketType.command) + "set_gpio_1_low"
                header = struct.pack("!II", 0xdeadbeef, len(payload))
                self.sender.send(header+payload)
            else:
                self.high = True;
                payload = struct.pack('!I', PacketType.command) + "set_gpio_1_high"
                header = struct.pack("!II", 0xdeadbeef, len(payload))
                self.sender.send(header+payload)
        else:
            payload = struct.pack('!I', PacketType.command) + "get_frame"
            header = struct.pack("!II", 0xdeadbeef, len(payload))
            self.sender.send(header+payload)
            self.frame = True
        pass


class DataHandler:
    def __init__(self, packet_handler):
        self.packet_handler = packet_handler
        self.buffer = ''


    def handle_data(self, data):
        self.buffer += data
        header_size = 8
        if len(self.buffer) <= header_size:
            return

        magic, length = struct.unpack('!II', self.buffer[:8])

        if len(self.buffer) < header_size + length:
            return

        end = header_size + length;
        self.packet_handler.handle_packet(self.buffer[header_size:end])
        rest = self.buffer[end:]
        # clear buffer
        self.buffer = ''
        # handle rest of buffer
        self.handle_data(rest)


class PyRadarLibProtocol(Protocol):

    def __init__(self):
        self.packet_handler = PacketHandler(self)
        self.data_handler = DataHandler(self.packet_handler)

    def connectionMade(self):
        print "Connection was made"

    def dataReceived(self, data):
        self.data_handler.handle_data(data)

    def send(self, data):
        self.transport.write(data)

    def connectionLost(self, reason):
        print "Connection lost"


class TestClientFactory(ClientFactory):

    protocol = PyRadarLibProtocol

    def clientConnectionFailed(self, connector, reason):
        print "Connection failed - goodbye! -- ", reason
        reactor.stop()

    def clientConnectionLost(self, connector, reason):
        print "Connection lost - goodbye! -- ", reason
        reactor.stop()


def main():
    factory = TestClientFactory()
    reactor.connectTCP("127.0.0.1", 5555, factory)
    reactor.run()


if __name__ == '__main__':
    main()








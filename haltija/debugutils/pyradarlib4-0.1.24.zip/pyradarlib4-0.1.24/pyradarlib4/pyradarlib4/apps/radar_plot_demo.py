import platform
import numpy as np
from matplotlib import pyplot as pl
from matplotlib import animation
from time import time
import pyradarlib4
from pyradarlib4.x4driver import DiscardingFrameQueue    
    
class Animator(object):
    def __init__(self,fig=None):
        if platform.system()=='Darwin':
            self.useblit=False
        else:
            self.useblit=True
        if fig:
            self.fig=fig
        else:
            self.fig=pl.figure()
        self.lines=[]
        self.deques=[]
        self.updaters=[]
        #ax = fig.add_subplot(rows,cols,1, xlim=(x[0],x[-1]),ylim=(r.var.ZoomMin, r.var.ZoomMax))
        #line, = ax.plot([],[],label='realtime')
        #ax.grid()
        self.i=0
        self.tic=time()
        
        self.pause = False

        #Auto zoom on button press
        def on_press(event):
            # right mouse click
            if event.button == 3:
                self.pause ^= True
                return

            axs = self.fig.get_axes()
            ax = axs[0]
            line=ax.get_lines()[0]
            y=np.array(line.get_ydata())

            ymin,ymax = y.min(),y.max()
            ax.set_ylim(ymin,ymax)
            
            for quad in self.lines:
                try:
                    a, b = quad.get_clim()
                except AttributeError:
                    continue
                quad.set_clim(ymin,ymax)

            self.fig.canvas.draw()
        
        def on_resize(event):
            for p in self.lines:
                try:
                    a, b = p.get_clim()
                except AttributeError:
                    continue

                ax = self.fig.get_axes()[0]
                
                a,b = ax.get_ylim()
                y=p.get_array()
                a,b = y.min(), y.max()
                p.set_clim(a,b)
                self.fig.canvas.draw()

            
                
            
        self.fig.canvas.mpl_connect('button_press_event', on_press)
        #self.fig.canvas.mpl_connect('button_release_event', on_resize)
        
        self._array_len=100

    def add_line(self, update_function, x=None, rows=1, cols=1, fign=1, array_len = None, xlabel='', ylabel=''):
        from numbers import Number
        ax = self.fig.add_subplot(rows, cols, fign)
        line, = ax.plot([],[])
        self._array_len = array_len
        
        y=update_function()
        if isinstance(y, Number):
            if array_len==None:
                self._array_len = 100
            self._y_array = np.ones(self._array_len)*y
            def update_function_wrapper(i):
                self._y_array[i] = update_function()
                return self._y_array
        else:
            update_function_wrapper = lambda i: update_function()
        
        y=update_function_wrapper(0) 
        
        try:
            if x==None:
                x=np.arange(len(y))
        except ValueError:
            pass
        
        ax.set_xlabel(xlabel)
        ax.set_ylabel(ylabel)        
        
        ax.set_xlim(x[0],x[-1])
        ymin=np.min(y[1:])*0.9
        ymax=np.max(y) + abs(np.max(y))*.1
        
        ax.set_xlim(x[0],x[-1])
        ax.set_ylim(ymin,ymax)
        
        
        self.lines.append(line)
        updater = lambda i: line.set_data(x,update_function_wrapper(i))
        self.updaters.append(updater)    

    def add_mesh(self, update_function, rows=2, cols=1, fign=1, cmap = pl.get_cmap('gray'), ylim=None):
        """ Add a 2D plot using pcolormesh
        """
                
        ax = self.fig.add_subplot(rows, cols, fign)   
        ax2 = None
            
        y=update_function()

        pdsum = np.sum(y, axis=1)
        pdsum_x = np.arange(len(pdsum))
        quad = ax.pcolormesh(y, cmap = cmap)
        
        
        ax.set_xlim(0, np.size(y,1))
        
        if ylim is not None:
            ax.set_ylim(ylim)
        else:
            ax.set_ylim(0, np.size(y,0))
            
        quad.set_clim(np.min(y), np.max(y))
        self.lines.append(quad)

        if ax2:
            self.lines.append(line)
            
        def updater(i):
            data = update_function()
            quad.set_array(data.ravel()) 
                
        self.updaters.append(updater)    


    def init(self):
        for line in self.lines:
            try:
                line.set_data([],[])
            except AttributeError:
                pass
                    
            pass
        return self.lines
        #pass

    
    def animate(self, i=1):
        if self.pause:
            return self.lines
        for updater in self.updaters:
            updater(i)
            #self.deques[len(self.deques)-1].append(update_function())
            #print self.deques[0]
            
        return self.lines


    def start(self, interval = 'auto'):
        #self.fig.tight_layout()
        t0 = time()
        self.animate(0)
        t1 = time()
        print interval
        if interval=='auto':
            self.interval = 1000 * (t1 - t0)
        else:
            self.interval=interval
        print self.interval

        self.anim = animation.FuncAnimation(self.fig, self.animate, init_func=self.init,
                               frames=self._array_len, interval=self.interval, blit=self.useblit)


cluttermap = None
last_frame = None
pdmatrix   = None


        
def radar_pdplot_demo(radar, length=100, fps=50, update_interval=100, fzoom=100, filter_b = [-1, 1], compensate_filter=False):
    """ Live pulse doppler plotting demo
    
    Todo: Still needs a bit of tuning to look good

    Expects a X4Driver object. Sets up on-chip downconversion and runs
    pulse doppler processing on the incoming data.

    Also applies a basic highpass filter in slow time. To disable, set filter_b to [1].
    Set compensate_filter to True to compensate for the filter response (doesn't work properly yet)
    
    >>> from pyradarlib4 import X4Driver
    >>> from pyradarlib4.apps import radar_2dplot_demo    
    >>> radar = X4Driver()
        ...
    >>> radar_pdplot_demo(radar)
    
    """ 
    from time import sleep
    from scipy.signal import freqz, lfilter
    
    def get_data():
        
        data_as_array = np.array(q.queue)
            
        pddb = np.zeros_like(data_as_array[:,4:])
        for i in range(len(data_as_array[0,4:])):
            tmp_y     = lfilter(filter_b, [1], data_as_array[:,4+i])
            tmp_Y     = np.fft.fft(tmp_y)#np.fft.fft(data_as_array[:,4+i])
            tmp_pd    = np.fft.fftshift(tmp_Y)
            tmp_pdpwr = np.real(tmp_pd * np.conj(tmp_pd))
            
            #pd[:,i] = np.fft.fftshift(tmp_Y)      
            if compensate_filter:
                pddb[:,i] = 10*np.log10(tmp_pdpwr) - filter_resp_db
            else:
                pddb[:,i] = 10*np.log10(tmp_pdpwr)
            
        #pdpwr = np.real(pd * np.conj(pd))
        #pddb  = 10*np.log10(pdpwr)            
            
        #clutter = np.mean(data_as_array, axis=0)
        #data_as_array = data_as_array-clutter
        return pddb

    rows = 1
    cols = 1
    cut_start = length/2 - length*0.01
    cut_stop  = length/2 + length*0.01
    #filter_b = [-1, 1]
    filter_resp_w, filter_resp_h = freqz(filter_b, [1], worN=length, whole=True)
    filter_resp = np.real(filter_resp_h * np.conj(filter_resp_h))
    filter_resp = (filter_resp / np.max(filter_resp))*0.1
    filter_resp_db = np.fft.fftshift(10*np.log10(filter_resp))
    filter_resp_db[cut_start:cut_stop] = filter_resp_db[cut_start]
   
    q =     DiscardingFrameQueue(length)
    radar.enable_downconversion()
    radar.set_iq_frame_buffer(q)
    radar.radar.set_fps(fps)

    while(not q.full()):
        status = q.qsize()
        print "Waiting for buffer to fill. Currently at (%d / %d)" % (status, length)
        sleep(1)
        
    faxis = (fps/2*np.linspace(-1,1,length+1))[0:length];                

    ylim = ((length/2)-(fzoom/2),(length/2)+(fzoom/2))
    print ylim
    a = Animator()        
    a.add_mesh(get_data, rows, cols, 1, cmap=pl.get_cmap('coolwarm'),ylim=ylim)

    pl.ion()
    a.start(interval=update_interval)#interval = 10./r.extras.stream.fps)
    pl.show()
    
    return a
       
def radar_2dplot_demo(radar, length=100, interval=50):
    """ 2 dimensional plotting demo (aka graymap)
    
    Supply a radar object and the function takes care of the rest
    Note that this function uses the streaming mode of pyradarlib under the 
    hood and attempts to set an fps based on the interval input. This might
    not work correctly for arbitrary values of fps.
    
    >>> from pyradarlib4 import X4Driver
    >>> from pyradarlib4.apps import radar_2dplot_demo    
    >>> radar = X4Driver()
        ...
    >>> radar_2dplot_demo(radar)
    """
    from time import sleep
    
    def get_data():
        if q == None:
            data_as_array = np.random.randn(10,10)
        else:
            data_as_array = np.array(q.queue)
        clutter = np.mean(data_as_array, axis=0)
        data_as_array = data_as_array-clutter
        return data_as_array

    rows = 1
    cols = 1
    
    q =     DiscardingFrameQueue(length)
    radar.set_frame_buffer(q)
    radar.radar.set_fps(1000/interval)
    sleep(1)
    a = Animator()        
    a.add_mesh(get_data, rows, cols, 1)

    pl.ion()
    a.start(interval=interval)#interval = 10./r.extras.stream.fps)
    pl.show()
    
    return a


def radar_plot_demo(radar=None, bb = True, acm=False, acm_w=0.1):
    """! Live time domain radar plotting demo.

    Initiates a new radar object if not given. Plots raw radar data or 
    Baseband data with optional adaptive clutter map.

    Parameters:
        r: radar object. A new radar object will be initiated if None and
            default setting will be set.
        bb: enable baseband from chip
        acm: enable adaptive clutter map
        acm_w: adaptive clutter map weight

    Returns:
        a,r: tuple of animator and radar object
    """

    from matplotlib.mlab import psd
    from numpy.fft import fft
    from matplotlib import pyplot as plt
    from matplotlib import cm
    from pyradarlib4.apps import filters
    import pyradarlib4
    
    r=radar
    
    f = filters.Filters()
    if not bb:
        f_mean = filters.Mean()
        f.register(f_mean)
    if acm:
        f_acm = filters.AdaptiveClutterMap(w=acm_w)
        f.register(f_acm)
    if bb:
        f_abs = filters.Abs()
        f.register(f_abs)

    if r==None:
        r = pyradarlib4.X4Driver()
        r.set_dacmin(950)
        r.set_dacmax(1100)
        r.set_pps(200)
        r.set_sample_delay(2)
        r.set_prf(18)

    if bb:
        r.enable_downconversion()
    else:
        print "TODO: disable downconversion"
        
    
    def update_frame():
        global frame, static_clutter_map,static_clutter_map_enable
        frame = r.get_frame_normalized()
        frame = f.filter(frame)
        if static_clutter_map_enable:
            frame-=static_clutter_map
        return frame

    def get_frame():
        global frame

        
        return frame 
    
    global static_clutter_map
    static_clutter_map = 0
    global static_clutter_map_enable
    static_clutter_map_enable = False

    frame=update_frame()

    frames = np.zeros((100, len(frame)))
    import collections
    global framebuffer
    framebuffer = collections.deque(frames, maxlen=100)



    def update_scm(event):
        global static_clutter_map_enable, static_clutter_map, frame
        if event.key=='c':
            static_clutter_map_enable ^= True
            static_clutter_map = frame
            print "Static cluttermap:",static_clutter_map_enable
    

    def get_framebuffer():
        global frame, frames, framebuffer
        framebuffer.appendleft(frame)
        return np.array(framebuffer)

    fs = r.get_fs()
    sd = r.get_sample_delay()
    
    c = 299792458.
    N=len(frame)
    x =  (sd + np.arange(N)/fs)*c/2
    

    a = Animator()
    a.add_line(update_frame, x, 2,1,1, xlabel='Distance [m]')
    
    
    a.add_mesh(get_framebuffer, rows=2,cols=1,fign=2, cmap=cm.viridis)
    pl.gca().set_xlabel("Bin #")
    
    a.fig.suptitle("Left click to scale data from upper plot data limits.\nRight click to pause. 'c' to enable/disable static cluttermap")
    a.fig.canvas.mpl_connect('key_press_event',update_scm)
    a.start()

    return a,r



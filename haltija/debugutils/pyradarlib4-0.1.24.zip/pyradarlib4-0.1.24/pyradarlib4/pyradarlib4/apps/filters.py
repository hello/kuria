from __future__ import division
import numpy as np
from scipy.signal import lfilter



class FilterBase(object):
    def filter_dataset(self, frames):
        
        # figure out the data type:
        res = self.filter(frames[0])
        
        fframes=np.zeros(frames.shape, dtype=res.dtype)
        for i, frame in enumerate(frames):
            fframes[i] = self.filter(frame)
        
        return fframes

class Filters(FilterBase):
    def __init__(self):
        self._filters = []
        
    def register(self, filter):
        self._filters.append(filter)
        
    def filter(self, frame):
        for filter in self._filters:
            frame = filter.filter(frame)
        return frame


class AdaptiveClutterMap(object):
    def __init__(self, w=0.01):
        self.cluttermap = None
        self.w=w
    
    def filter(self, frame):
        if self.cluttermap==None:
            self.cluttermap = frame.copy()

        clutter = frame - self.cluttermap
        self.cluttermap = (1-self.w)*self.cluttermap + self.w * frame
        return clutter

    def filter_dataset(self,frames):
        cmap = np.zeros_like(frames)
        self.cluttermap=frames[0]

        for iframe, frame in enumerate(frames):
            cmap[iframe] = self.filter(frame)

        return cmap


class Abs(FilterBase):        
    def filter(self, frame):
        return np.abs(frame)
    
class Mean(FilterBase):
    def filter(self, frame):            
        return frame-frame.mean()
           
               


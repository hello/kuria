from socketserver_extended import read_packet, recv_all
import unittest
import struct


class MockSocket:
    def __init__(self, msg):
        self.msg = msg
        #print "self.msg: ", self.msg
        self.count = 0
        self.rest = ''

    def recv(self, max_size):
        #print "recv ", max_size
        result = self.msg[self.count]
        if not result:
            return None
        #print result
        if len(result) > max_size:
            raise Exception("packet is bigger than max size")

        self.count += 1
        return result


class test_recv_all(unittest.TestCase):

    def test_recvall_all_in_one(self):
        packet1 = "abc"
        packet2 = "def"
        socket = MockSocket((packet1, packet2))
        self.assertEqual("abcdef", recv_all(socket, len(packet1 + packet2)))

    def test_recvall_all_in_another_combo(self):
        packet1 = "a"
        packet2 = "bcdef"
        socket = MockSocket((packet1, packet2))
        self.assertEqual("abcdef", recv_all(socket, len(packet1 + packet2)))

    def test_recv_all_return_none_when_recv_return_zero_bytes(self):
        packet1 = "bla"
        packet2 = ""
        socket = MockSocket((packet1, packet2))
        self.assertEqual(None, recv_all(socket, len(packet1) + 1))


class test_read_packet(unittest.TestCase):

    def test_header_only(self):
         message = struct.pack('!II', 0xdeadbeef, 0)
         #print message
         socket = MockSocket([message[:4], message[4:]])
         self.assertEqual("", read_packet(socket))

    def test_header_and_payload(self):
        payload = "hello"
        magic = struct.pack('!I', 0xdeadbeef)
        length = struct.pack('!I', len(payload))
        socket = MockSocket((magic, length, payload))
        self.assertEqual(payload, read_packet(socket))

    def test_header_and_payload_more_fractioned(self):
        payload = "hello"
        magic = struct.pack('!I', 0xdeadbeef)
        length = struct.pack('!I', len(payload))
        socket = MockSocket((magic[:3], magic[3:], length[:1], length[1:], payload))
        self.assertEqual(payload, read_packet(socket))


    def test_returns_no_bytes_during_magic_bytes(self):
        payload = "hello"
        magic = struct.pack('!I', 0xacdcabba)
        socket = MockSocket((magic[:3], None))
        self.assertEqual(None, read_packet(socket))

    def test_returns_none_in_case_of_miss_in_magic(self):
        payload = "hello"
        magic = struct.pack('!I', 0xaaaabbbb)
        length = struct.pack('!I', len(payload))
        socket = MockSocket((magic, length, payload))
        self.assertEqual(None, read_packet(socket))


if __name__ == "__main__":
    unittest.main()

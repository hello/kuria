import socket
import errno
import struct
import enum
import numpy as np
from time import time,sleep

class SocketServer(object):
    def __init__(self, timeout=60, port=5555):
        """ Initialize a new socketserver object
        """
        self.host = ''
        self.port = port
        #create an INET, STREAMing socket
        self.serversocket = socket.socket( socket.AF_INET, socket.SOCK_STREAM)
        self.serversocket.settimeout(timeout)
        self.serversocket.bind((self.host, self.port))
        self.serversocket.listen(5)

    def connect(self):
        self.serversocket.connect((self.host, self.port))

    def send(self,data):
        self.serversocket.send(data)

    def wait_for_socket(self):
        clientsocket, address = self.serversocket.accept()
        return clientsocket

    def __enter__(self):
        """
        For PEP 343
        """
        try:
            return self.wait_for_socket()
        except socket.timeout:
            return None

    def __exit__(self, *args):
        """
        For PEP 343:
        Called when object is destroyed when exiting with statement
        Makes sure the class cleans up after it self by stopping the
        firmware and closing the connection.
        """
        self.serversocket.close()


class PacketType(enum.IntEnum):
    frame = 1
    command = 2
    response = 3
    framelength = 4

def recv_all(sock, count):
    buf = b''
    while count:
        try:
            newbuf = sock.recv(count)
            if not newbuf:
                return None
            buf += newbuf
            count -= len(newbuf)

        except socket.error as e:
            err = e.args[0]
            if err == errno.EAGAIN or err == errno.EWOULDBLOCK:
                # No data received, try again
                continue
            else:
                print "Error receiving data", e
                return None

    return buf


def read_packet(socket):
    magic_bytes = recv_all(socket, 4)
    if not magic_bytes:
        return None
    magic, = struct.unpack('!I', magic_bytes)
    if magic != 0xdeadbeef:
        return None
    length_bytes = recv_all(socket, 4)
    if not length_bytes:
        return None
    length, = struct.unpack('!I', length_bytes)
    if length == 0:
        return ""
    packet = recv_all(socket, length)
    return packet



def run_socketserver(radar, fps=20, bb=False, timeout=60, port=5555):
    """ Run a socketserver instance

    The function expects an initialized radar object, with no streaming operation running.

    Parameters:
    ------------------
    radar   : An initialized pyradarlib4 object (or something similar such as an X4Driver object)
    fps     : Integer, optional
        The desired FPS
    bb      : boolean, optional
        If true, use baseband (IQ) data. If false, use RF data.
        Note that the radar object has to be properly initialized to use baseband data!
    timeout : integer, optional
        TCP connection timeout in seconds
    port    : integer, optional
        TCP port
    """
    from Queue import Queue

    print "Waiting for client connection (you have %d seconds before timeout!)" % timeout

    with SocketServer(timeout=timeout, port=port) as the_socket:
        if the_socket == None:
            print "Failed to connect to client"
            return

        print "Connected to", the_socket.getsockname()
        q = Queue()

        if bb:
            framelength = len(radar.sample_iq_frame())
            radar.set_iq_frame_buffer(q)
        else:
            framelength = len(radar.sample_frame())
            radar.set_frame_buffer(q)

        radar.radar.set_fps(fps)

        if bb:
            frame = np.zeros(framelength+1,dtype='complex')
        else:
            frame = np.zeros(framelength+1,dtype='int32')

        # Send frame length
        payload = struct.pack('!II', PacketType.framelength, framelength)
        header = struct.pack('!II', 0xdeadbeef, len(payload))
        the_socket.sendall(header + payload)

        #the_socket.sendall(np.array(framelength,dtype='int32').tobytes())

        n = 0
        timea = time()
        while(1):
            packet = read_packet(the_socket)
            sizeof_packet_id = 4
            if not packet or len(packet) < sizeof_packet_id:
                # If a zero-length msg is received, this indicates that the client shut down the connection
                # If there was just no data to read, the EAGAIN or EWOULDBLOCK exceptions are thrown
                print "Client shut down, exiting"
                break

            packet_id_bytes = packet[:sizeof_packet_id]
            packet_id, = struct.unpack('!I', packet_id_bytes)
            packet = packet[sizeof_packet_id:]

            if packet_id != PacketType.command:
                print "exit wrong packet id", packet_id, PacketType.command, packet_id == PacketType.command
                break

            msg = packet
            #print msg
            if msg == "get_frame":
                data = q.get()
                frame[1:] = data.data
                frame[0]  = data.number

                # Record the initial frame number
                # The frame counter is an 32-bit uint
                # so it could theoretically wrap but with practical
                # frame rates this would take a very, very long time..
                if n == 0:
                    frame0 = data.number
                n = n + 1

                try:
                    payload = struct.pack('!I', PacketType.frame) + frame.tobytes()
                    header = struct.pack('!II', 0xdeadbeef, len(payload))
                    the_socket.sendall(header + payload)
                except socket.error as e:
                    # Todo: We should probably find a more graceful method of closing the connection
                    print "Error sending data, the client probably closed the connection"
                    print e
                    break

            else:
                response = "ok"
                from pyradarlib4.radardefinitions import IoportValue
                if radar.pins.use_mcu02_setup == 1:

                    if msg == "set_gpio_1_high":
                        radar.pins.MCU02_USER_IO1.setHigh()
                    elif msg == "set_gpio_1_low":
                        radar.pins.MCU02_USER_IO1.setLow()
                    elif msg == "set_gpio_2_high":
                        radar.pins.MCU02_USER_IO2.setHigh()
                    elif msg == "set_gpio_2_low":
                        radar.pins.MCU02_USER_IO2.setLow()
                    elif msg == "get_gpio_1":
                        if radar.pins.MCU02_USER_IO1.getVal() == IoportValue.IOPORT_PIN_LEVEL_HIGH:
                            response = "ok"
                        elif radar.pins.MCU02_USER_IO1.getVal() == IoportValue.IOPORT_PIN_LEVEL_LOW:
                            response = "nok"
                        else:
                            response = "error"
                    elif msg == "get_gpio_2":
                        if radar.pins.MCU02_USER_IO2.getVal() == IoportValue.IOPORT_PIN_LEVEL_HIGH:
                            response = "ok"
                        elif radar.pins.MCU02_USER_IO2.getVal() == IoportValue.IOPORT_PIN_LEVEL_LOW:
                            response = "nok"
                        else:
                            response = "error"
                    else:
                            response = "nok"
                else:
                    response = "nok"
                try:
                    payload = struct.pack('!I', PacketType.response) + response
                    header = struct.pack('!II', 0xdeadbeef, len(payload))
                    the_socket.sendall(header + payload)
                except socket.error as e:
                    # Todo: We should probably find a more graceful method of closing the connection
                    print "Error sending data, the client probably closed the connection"
                    print e
                    break


    # End of with-statement, the socket should be closed automagically
    # Stop radar streaming
    radar.radar.set_fps(0)

    timeb       = time()
    timelapsed  = timeb - timea
    fps         = n / timelapsed
    framecount  = data.number - frame0 + 1

    print "---------------------------------------------------------------"
    print "Received %d frames in %f seconds. That is an average of %f FPS." % (n,timelapsed,fps) 
    print "The first frame number was %d, and the last was %d, that gives a firmware framecount of %d" % (frame0,data.number,framecount)
    if framecount == n:
        print "Firmware framecount matches the received number of frames, so no frames seem to have been lost."
    else:
        print "Firmware framecount doesn't match the received number of frames"
    if q.qsize()>0:
        print "There are %d frames left in the frame queue." % q.qsize()
    print "---------------------------------------------------------------"


def init_gpio(radar):
    if radar.pins.use_mcu02_setup == 1:
        radar.pins.MCU02_USER_IO1.setEnable()
        radar.pins.MCU02_USER_IO1.setOutput()
        radar.pins.MCU02_USER_IO2.setEnable()
        radar.pins.MCU02_USER_IO2.setInput()
    else:
        print "Warning:MCU01 setup detected, GPIO pins will be dissabled per Matlab team request.GPIO commands from matlab will not work. Reqest to get a MCU02 module if you want to use the GPIO commands."



def main():
    from pyradarlib4 import X4Driver
    
    r = X4Driver()
    r.set_pps(550)
    r.set_dacmax(1100)
    r.set_dacmin(950)
    init_gpio(r)
    run_socketserver(r, fps=20, bb=False, timeout=60, port=5555)
    

if __name__ == "__main__":
    main()

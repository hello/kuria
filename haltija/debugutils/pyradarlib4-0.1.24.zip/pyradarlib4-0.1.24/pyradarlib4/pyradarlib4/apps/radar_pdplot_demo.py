""" Live pulse doppler plotting demo

Todo: Still needs a bit of tuning to look good

Sets up on-chip downconversion and runs
pulse doppler processing on the incoming data.

Also applies a basic highpass filter in slow time. To disable, set filter_b to [1].
Set compensate_filter to True to compensate for the filter response (doesn't work properly yet)


""" 

from pyqtgraph.Qt import QtCore, QtGui
import pyqtgraph.opengl as gl
import pyqtgraph as pg
from time import time,sleep
import pyradarlib4
import numpy as np
from scipy.signal import freqz, lfilter,hanning
from pyradarlib4.x4driver import DiscardingFrameQueue

        
"""
Parameters:
-------------
length            : Length of pulse doppler integration
fps               : The desired FPS
update_interval   : The update interval of the plot in msecs
fzoom             : Zoom on frequency axis
filter_b          : Coefficients for MTI filter
compensate_filter : Set to True to compensate for MTI filter
pdwin             : Pulse-doppler window coefficients (default is a hanning window)
"""
radar = pyradarlib4.X4Driver()
length=200
fps=50
update_interval=30
fzoom=length # Set to lower than length to zoom in on the doppler axis
filter_b = [-1, 1]
compensate_filter=False
pdwin = hanning(length)

    



def get_data():
    
    q.mutex.acquire()
    data_as_array = np.array(q.queue)
    q.mutex.release()
    
    pddb = np.zeros_like(data_as_array[:,4:])
    for i in range(len(data_as_array[0,4:])):
        tmp_y     = lfilter(filter_b, [1], data_as_array[:,4+i])
        tmp_Y     = np.fft.fft(tmp_y*pdwin)#np.fft.fft(data_as_array[:,4+i])
        tmp_pd    = np.fft.fftshift(tmp_Y)
        tmp_pdpwr = np.real(tmp_pd * np.conj(tmp_pd))
        
        #pd[:,i] = np.fft.fftshift(tmp_Y)      
        if compensate_filter:
            pddb[:,i] = 10*np.log10(tmp_pdpwr) - filter_resp_db
        else:
            pddb[:,i] = 10*np.log10(tmp_pdpwr)
        
    #pdpwr = np.real(pd * np.conj(pd))
    #pddb  = 10*np.log10(pdpwr)            
        
    #clutter = np.mean(data_as_array, axis=0)
    #data_as_array = data_as_array-clutter
    return np.real(pddb)

#rows = 1
#cols = 1

cut_start = int(length/2 - length*0.01)
cut_stop  = int(length/2 + length*0.01)
#filter_b = [-1, 1]
filter_resp_w, filter_resp_h = freqz(filter_b, [1], worN=length, whole=True)
filter_resp = np.real(filter_resp_h * np.conj(filter_resp_h))
filter_resp = (filter_resp / np.max(filter_resp))*0.1
filter_resp[cut_start:cut_stop] = filter_resp[cut_start]
filter_resp_db = np.fft.fftshift(10*np.log10(filter_resp))
#filter_resp_db[cut_start:cut_stop] = filter_resp_db[cut_start]

q =     DiscardingFrameQueue(length)
radar.enable_downconversion()
radar.set_iq_frame_buffer(q)
radar.radar.set_fps(fps)

while(not q.full()):
    status = q.qsize()
    print "Waiting for buffer to fill. Currently at (%d / %d)" % (status, length)
    sleep(1)
    
faxis = (fps/2*np.linspace(-1,1,length+1))[0:length];                

ylim = ((length/2)-(fzoom/2),(length/2)+(fzoom/2))
print ylim

###
### From GLSurfacePlot example
app = QtGui.QApplication([])
w = gl.GLViewWidget()
w.show()
w.setWindowTitle('pyqtgraph example: GLSurfacePlot')
w.setCameraPosition(distance=50)

z  = get_data()
xlorg = np.size(z,0)
xlzoomstart = xlorg/2 - fzoom/2
xlzoomstop  = xlorg/2 + fzoom/2

xl = fzoom # np.size(z,0)
yl = np.size(z,1)
mi = np.min(z)
ma = np.max(z)
ra = ma - mi        
        
#    cols = 90
#    rows = 100
x = np.linspace(-10, 10, xl).reshape(xl,1)
y = np.linspace(-10, 10, yl).reshape(1,yl)
d = (x**2 + y**2) * 0.1
d2 = d ** 0.5 + 0.1

## create a surface plot, tell it to use the 'heightColor' shader
## since this does not require normal vectors to render (thus we 
## can set computeNormals=False to save time when the mesh updates)
p4 = gl.GLSurfacePlotItem(x=x[:,0], y = y[0,:], shader='heightColor', computeNormals=False, smooth=False)
#p4.shader()['colorMap'] = np.array([0.2, 2, 0.5, 0.2, 1, 1, 0.2, 0, 2])
p4.shader()['colorMap'] = np.array([0.4, 0, 1, 0.2, 0, 1, -0.2, 0, 1])
p4.translate(5, 5, 0)
w.addItem(p4)

def update():
    za = get_data()[xlzoomstart:xlzoomstop,:]
    # Handtuned for now to get a nice looking plot.
    z = 5*(za - mi - 30) / (ma-mi)
    p4.setData(z=z)

timer = QtCore.QTimer()
timer.timeout.connect(update)
timer.start(update_interval)

    
    #update()
    #sleep(10)
    #a = Animator()        
    #a.add_mesh(get_data, rows, cols, 1, cmap=pl.get_cmap('coolwarm'),ylim=ylim)

    #pl.ion()
    #a.start(interval=update_interval)#interval = 10./r.extras.stream.fps)
    #pl.show()

    #return a
    

  

        
        

import struct


def btoi(bytes):
    """! Convert 4 bytes represented in either a list, a bytearray or a byte-formatted string to an int
    @param bytes The array of bytes to be converted
    """
    return struct.unpack('I',bytes)[0]


def btol(bytes):
    return struct.unpack('Q', bytes)[0]